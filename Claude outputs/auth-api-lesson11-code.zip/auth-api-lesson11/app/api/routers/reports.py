# Отчёты: поставить задачу в Celery, узнать её статус, скачать готовый файл.
from celery.result import AsyncResult
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse

from app.tasks.celery_app import celery_app
from app.tasks.reports import REPORTS_DIR, generate_users_report

router = APIRouter(prefix='/reports', tags=['Отчёты (Celery)'])


@router.post('/users', status_code=status.HTTP_202_ACCEPTED)
def create_users_report():
    task = generate_users_report.delay()
    return {'task_id': task.id, 'status_url': f'/reports/tasks/{task.id}'}


@router.get('/tasks/{task_id}')
def get_task_status(task_id: str):
    result = AsyncResult(task_id, app=celery_app)
    response = {'task_id': task_id, 'status': result.status}
    if result.status == 'PROGRESS':
        response['progress'] = result.info            # {'done': 12, 'total': 44}
    elif result.successful():
        response['result'] = result.result
    elif result.failed():
        response['error'] = str(result.result)       # текст исключения
    return response


@router.get('/download/{task_id}')
def download_report(task_id: str):
    result = AsyncResult(task_id, app=celery_app)
    if not result.successful():
        raise HTTPException(status_code=404, detail='Отчёт ещё не готов')
    path = REPORTS_DIR / result.result['file']
    return FileResponse(path, media_type='text/csv', filename='users_report.csv')
