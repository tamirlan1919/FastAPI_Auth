# Письма через Celery: с автоматическими повторами при сбое почтового сервера.
from app.services.email_service import EmailSendError, send_welcome_email
from app.tasks.celery_app import celery_app
from app.tasks.utils import run_async


@celery_app.task(
    bind=True,
    autoretry_for=(EmailSendError,),  # на этой ошибке — повторить
    retry_backoff=2,                  # пауза 2, 4, 8... секунд между попытками
    retry_jitter=False,               # без случайного разброса — чтобы на уроке было предсказуемо
    max_retries=3,                    # не больше 3 повторов, потом FAILURE
)
def send_welcome_email_task(self, email: str, username: str) -> str:
    attempt = self.request.retries + 1
    print(f'📨 Попытка {attempt}: письмо для {email}')
    if email.startswith('flaky') and attempt < 3:      # «почта моргнула»: первые 2 попытки падают
        raise EmailSendError('SMTP временно недоступен')
    run_async(send_welcome_email(email, username))
    return f'sent to {email}'
