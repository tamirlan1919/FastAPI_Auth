# Мост между синхронным Celery и нашим асинхронным кодом (SQLAlchemy async, redis.asyncio).
import asyncio

from app.db.database import engine


def run_async(coro):
    async def runner():
        try:
            return await coro
        finally:
            await engine.dispose()   # закрыть соединения с БД: следующий asyncio.run будет с новым event loop
    return asyncio.run(runner())
