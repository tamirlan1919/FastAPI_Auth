# Задачи по расписанию (Celery Beat): ежедневная статистика в Redis.
from datetime import date, datetime, time

from sqlalchemy import func, select

from app.db.database import async_session_maker
from app.db.models import Post, User
from app.db.redis_db import create_redis
from app.tasks.celery_app import celery_app
from app.tasks.utils import run_async


async def collect_stats() -> dict:
    today_start = datetime.combine(date.today(), time.min)
    async with async_session_maker() as session:
        users_total = await session.scalar(select(func.count(User.id)))
        users_today = await session.scalar(
            select(func.count(User.id)).where(User.created_at >= today_start)
        )
        posts_total = await session.scalar(select(func.count(Post.id)))

    stats = {
        'users_total': users_total,
        'users_today': users_today,
        'posts_total': posts_total,
        'collected_at': datetime.now().isoformat(timespec='seconds'),
    }
    redis = create_redis()
    await redis.hset(f'stats:daily:{date.today()}', mapping=stats)
    await redis.aclose()
    return stats


@celery_app.task
def collect_daily_stats() -> dict:
    return run_async(collect_stats())
