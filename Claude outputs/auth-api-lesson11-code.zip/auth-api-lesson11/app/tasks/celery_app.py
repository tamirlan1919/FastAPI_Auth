# Приложение Celery: где брать задачи (брокер), куда класть результаты и какие модули с задачами загрузить.
from celery import Celery

from app.core.config import settings

celery_app = Celery(
    'auth_api',
    broker=settings.rabbit_url,                # очередь задач — в нашем RabbitMQ
    backend=settings.celery_result_backend,    # статусы и результаты — в Redis, база №1
    include=['app.tasks.demo', 'app.tasks.reports', 'app.tasks.emails', 'app.tasks.periodic'],
)

celery_app.conf.update(
    task_track_started=True,   # показывать статус STARTED, пока задача выполняется
    result_expires=3600,       # хранить результат в Redis 1 час
    timezone='UTC',
)

# Расписание для Celery Beat
celery_app.conf.beat_schedule = {
    'daily-stats': {
        'task': 'app.tasks.periodic.collect_daily_stats',
        'schedule': 30.0,   # на уроке — каждые 30 секунд; в проде: crontab(hour=3, minute=0)
    },
}
