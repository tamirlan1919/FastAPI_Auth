# Приветственное письмо как задача Celery: повторы с растущей паузой, логи, защита от дублей.
from celery.utils.log import get_task_logger
from redis import Redis

from app.core.config import settings
from app.services.email_service import EmailSendError, send_welcome_email
from app.tasks.celery_app import celery_app
from app.tasks.utils import run_async

logger = get_task_logger(__name__)
redis_sync = Redis.from_url(settings.redis_url, decode_responses=True)  # Celery-задачи синхронные


@celery_app.task(bind=True, max_retries=4, soft_time_limit=30, time_limit=40)
def send_welcome_email_task(self, user_id: int, email: str, username: str) -> str:
    key = f'email:welcome:{user_id}'
    # SET NX: записать, только если ключа нет. Атомарно — второй такой же вызов получит False
    if not redis_sync.set(key, 'in_progress', nx=True, ex=600):
        logger.warning('Письмо для user_id=%s уже отправлено или отправляется — пропускаем', user_id)
        return 'skipped'

    try:
        if email.startswith('flaky') and self.request.retries < 2:   # учебная «моргающая» почта
            raise EmailSendError('SMTP временно недоступен')
        run_async(send_welcome_email(email, username))
    except EmailSendError as exc:
        redis_sync.delete(key)                    # отпустить ключ, чтобы повтор смог его взять
        countdown = 2 ** self.request.retries     # 1, 2, 4, 8 секунд
        logger.warning('Попытка %s для %s не удалась: %s. Повтор через %s с',
                       self.request.retries + 1, email, exc, countdown)
        raise self.retry(exc=exc, countdown=countdown)

    redis_sync.set(key, 'sent', ex=60 * 60 * 24 * 30)   # помним 30 дней
    logger.info('Письмо отправлено на %s', email)
    return f'sent to {email}'
