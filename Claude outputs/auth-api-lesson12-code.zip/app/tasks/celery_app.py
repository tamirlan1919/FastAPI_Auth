import os

from celery import Celery
from celery.schedules import crontab
from celery.signals import worker_init
from kombu import Exchange, Queue

from app.core.config import settings

# On macOS billiard starts prefork children via spawn instead of fork. Without this
# flag Celery skips initializing them and every task fails with
# "ValueError: not enough values to unpack (expected 3, got 0)".
os.environ.setdefault('FORKED_BY_MULTIPROCESSING', '1')

celery_app = Celery(
    'auth-api',
    broker=settings.rabbit_url,
    backend=settings.celery_result_backend,
    include=['app.tasks.demo', 'app.tasks.reports', 'app.tasks.emails', 'app.tasks.cpu'],
)

DLX = Exchange('celery.dlx', type='fanout')             # «корзина» для упавших задач
DLQ = Queue('celery.dlq', DLX, durable=True)            # очередь, где они ждут разбора

celery_app.conf.update(
    task_track_started=True,
    result_expires=3600,
    timezone='UTC',
    # RabbitMQ 4.x denies transient non-exclusive queues (transient_nonexcl_queues),
    # so Celery's pidbox (mingle/inspect) and gossip queues must be exclusive.
    control_queue_exclusive=True,
    event_queue_exclusive=True,

    # --- Урок 12: очереди и маршрутизация ---
    task_queues=[
        Queue('default'),
        Queue('reports'),
        Queue('emails', queue_arguments={
            'x-dead-letter-exchange': 'celery.dlx',   # окончательно упавшие — в DLQ
            'x-max-priority': 10,                     # очередь с приоритетами 0..10
        }),
    ],
    task_default_queue='default',
    task_routes={
        'app.tasks.reports.*': {'queue': 'reports'},
        'app.tasks.emails.*': {'queue': 'emails'},
    },

    # --- Урок 12: надёжность ---
    worker_prefetch_multiplier=1,           # брать по одной задаче на процесс
    task_acks_late=True,                    # ack только ПОСЛЕ выполнения задачи
    task_reject_on_worker_lost=True,        # воркер умер — вернуть задачу в очередь
    task_acks_on_failure_or_timeout=False,  # задача упала — reject, а не ack (→ DLQ)
)


@worker_init.connect
def declare_dlq(**kwargs):
    # Celery не создаёт DLX и DLQ сам — объявляем их при старте воркера
    with celery_app.connection_for_write() as conn:
        DLQ.bind(conn.default_channel).declare()


celery_app.conf.beat_schedule = {
    'send-report-every-morning': {
        'task': 'app.tasks.reports.generate_users_report',   # полное имя задачи, а не модуля
        'schedule': crontab(hour=21, minute=38),
    },
}
