import csv
import time

from celery.exceptions import SoftTimeLimitExceeded
from celery.utils.log import get_task_logger
from sqlalchemy import func, select

from app.core.config import BASE_DIR
from app.db.database import async_session_maker
from app.db.models import Post, User
from app.tasks.celery_app import celery_app
from app.tasks.utils import run_async

REPORTS_DIR = BASE_DIR / 'reports'
logger = get_task_logger(__name__)


async def load_users_with_posts() -> list[tuple]:
    async with async_session_maker() as session:
        stmt = (
            select(User.id, User.username, User.email, func.count(Post.id))
            .outerjoin(Post, Post.author_id == User.id)
            .group_by(User.id)
            .order_by(User.id)
        )
        return (await session.execute(stmt)).all()


@celery_app.task(bind=True, soft_time_limit=60, time_limit=90)
def generate_users_report(self, delay: float = 0.1) -> dict:
    rows = run_async(load_users_with_posts())
    REPORTS_DIR.mkdir(exist_ok=True)
    path = REPORTS_DIR / f'users_{self.request.id}.csv'
    logger.info('Строим отчёт: %s строк, файл %s', len(rows), path.name)

    try:
        with open(path, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['user_id', 'username', 'email', 'post_count'])
            for row in rows:
                writer.writerow(row)
                time.sleep(delay)
    except SoftTimeLimitExceeded:
        logger.error('Отчёт не уложился в лимит времени — удаляем недописанный файл')
        path.unlink(missing_ok=True)
        raise

    return {'file': path.name, 'rows': len(rows)}
