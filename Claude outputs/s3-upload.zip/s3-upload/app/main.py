from fastapi import FastAPI, HTTPException, UploadFile, status

from app.s3_storage import ALLOWED_TYPES, MAX_SIZE, S3Settings, S3Storage

app = FastAPI()
storage = S3Storage(S3Settings())


@app.post('/photos', status_code=status.HTTP_201_CREATED)
async def upload_photo(file: UploadFile):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, 'Можно только JPEG, PNG или WebP')
    data = await file.read(MAX_SIZE + 1)
    if len(data) > MAX_SIZE:
        raise HTTPException(413, 'Файл больше 10 МБ')
    key = await storage.upload_photo(data, file.content_type)
    return {'key': key, 'url': await storage.presigned_url(key)}


@app.get('/photos/{key:path}')
async def photo_url(key: str):
    return {'url': await storage.presigned_url(key)}
