import uuid
from contextlib import asynccontextmanager

import aioboto3
from botocore.config import Config
from pydantic import SecretStr
from pydantic_settings import BaseSettings


class S3Settings(BaseSettings):
    s3_endpoint_url: str                     # https://s3.twcstorage.ru
    s3_bucket: str                           # adrise-media
    s3_access_key: str
    s3_secret_key: SecretStr
    s3_region: str = 'ru-1'
    s3_presign_ttl: int = 3600               # сколько живёт временная ссылка, сек


ALLOWED_TYPES = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp'}
MAX_SIZE = 10 * 1024 * 1024                  # 10 МБ


class S3Storage:
    def __init__(self, settings: S3Settings):
        self.s = settings
        self._session = aioboto3.Session()
        self._config = Config(
            s3={'addressing_style': 'path'},  # https://s3.twcstorage.ru/adrise-media/<key>
            signature_version='s3v4',
        )

    @asynccontextmanager
    async def _client(self):
        async with self._session.client(
            's3',
            endpoint_url=self.s.s3_endpoint_url,
            aws_access_key_id=self.s.s3_access_key,
            aws_secret_access_key=self.s.s3_secret_key.get_secret_value(),
            region_name=self.s.s3_region,
            config=self._config,
        ) as client:
            yield client

    async def upload_photo(self, data: bytes, content_type: str, prefix: str = 'photos') -> str:
        """Загружает фото, возвращает ключ объекта (его и храним в БД, а не ссылку)."""
        key = f'{prefix}/{uuid.uuid4().hex}.{ALLOWED_TYPES[content_type]}'
        async with self._client() as s3:
            await s3.put_object(Bucket=self.s.s3_bucket, Key=key, Body=data, ContentType=content_type)
        return key

    async def presigned_url(self, key: str) -> str:
        """Временная ссылка на чтение из закрытого бакета."""
        async with self._client() as s3:
            return await s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': self.s.s3_bucket, 'Key': key},
                ExpiresIn=self.s.s3_presign_ttl,
            )

    async def delete(self, key: str) -> None:
        async with self._client() as s3:
            await s3.delete_object(Bucket=self.s.s3_bucket, Key=key)
