"""Обработчики ошибок и клиент GitHub — без Redis, RabbitMQ и интернета."""
import httpx
import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from pydantic import BaseModel

from app.clients.github import get_user
from app.core.error_handlers import install_error_handlers
from app.core.errors import ExternalServiceTimeout, ExternalServiceUnavailable, NotFoundError
from app.core.request_context import request_id_middleware
from app.services.auth_service import UserAlreadyExists


# --- маленькое приложение только с нашими обработчиками -----------------------
app = FastAPI()
install_error_handlers(app)
app.middleware('http')(request_id_middleware)


class Body(BaseModel):
    password: str


@app.get('/conflict')
async def conflict():
    raise UserAlreadyExists('Пользователь с таким email уже существует')


@app.get('/http')
async def http_error():
    raise HTTPException(status_code=403, detail='Нет доступа')


@app.post('/validate')
async def validate(body: Body):
    return body


@app.get('/bug')
async def bug():
    return 1 / 0


# raise_server_exceptions=False: иначе TestClient пробросит ZeroDivisionError в тест
client = TestClient(app, raise_server_exceptions=False)


def test_app_error_becomes_problem_json():
    r = client.get('/conflict')
    assert r.status_code == 409
    assert r.headers['content-type'] == 'application/problem+json'
    body = r.json()
    assert body['code'] == 'user_already_exists'
    assert body['request_id'] == r.headers['x-request-id']


def test_http_exception_keeps_format():
    r = client.get('/http')
    assert r.status_code == 403
    assert r.json()['detail'] == 'Нет доступа'


def test_validation_error_does_not_echo_input():
    r = client.post('/validate', json={'password': 123})
    assert r.status_code == 422
    assert r.json()['errors'][0]['field'] == 'password'
    assert '123' not in r.text            # пароль не вернулся клиенту


def test_unknown_route_is_problem_json():
    assert client.get('/nope').json()['code'] == 'not_found'


def test_unhandled_error_hides_details():
    r = client.get('/bug', headers={'X-Request-ID': 'test-42'})
    assert r.status_code == 500
    assert r.json()['request_id'] == 'test-42'
    assert 'division' not in r.text       # текст исключения клиенту не уходит


# --- клиент GitHub через MockTransport ----------------------------------------
def github(status: int, json: dict | None = None):
    return httpx.MockTransport(lambda request: httpx.Response(status, json=json or {}))


async def test_github_404_is_not_found():
    with pytest.raises(NotFoundError):
        await get_user('ghost', transport=github(404, {'message': 'Not Found'}))


async def test_github_rate_limit_is_503_not_403():
    with pytest.raises(ExternalServiceUnavailable):
        await get_user('octocat', transport=github(403, {'message': 'API rate limit exceeded'}))


async def test_github_timeout():
    def timeout(request):
        raise httpx.ReadTimeout('timeout', request=request)
    with pytest.raises(ExternalServiceTimeout):
        await get_user('octocat', transport=httpx.MockTransport(timeout))
