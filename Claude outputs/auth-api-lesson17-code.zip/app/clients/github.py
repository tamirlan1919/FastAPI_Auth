import logging

import httpx

from app.core.config import settings
from app.core.errors import (ExternalServiceError, ExternalServiceTimeout,
                             ExternalServiceUnavailable, NotFoundError)

logger = logging.getLogger(__name__)
SERVICE = 'github'


async def get_user(username: str, transport: httpx.AsyncBaseTransport | None = None) -> dict:
    """Профиль пользователя GitHub. Ошибки httpx и чужие статусы → наши исключения."""
    try:
        async with httpx.AsyncClient(base_url=settings.github_api_url, timeout=5.0,
                                     transport=transport) as client:
            response = await client.get(f'/users/{username}')
    except httpx.TimeoutException as e:
        raise ExternalServiceTimeout(SERVICE) from e
    except httpx.TransportError as e:            # не соединились: DNS, отказ, прокси
        raise ExternalServiceUnavailable(SERVICE) from e

    if response.status_code == 404:
        # Ответ GitHub «нет такого» — честный 404 и для нашего клиента
        raise NotFoundError(f'Пользователь GitHub «{username}» не найден')
    if response.status_code in (403, 429):
        # Лимит запросов GitHub — НЕ «у вас нет прав». Наш клиент тут ни при чём
        logger.warning('GitHub ограничил запросы: %s %s', response.status_code, response.text[:200])
        raise ExternalServiceUnavailable(SERVICE, 'GitHub временно ограничил запросы, попробуйте позже')
    if response.is_error:
        logger.error('GitHub ответил %s: %s', response.status_code, response.text[:200])
        raise ExternalServiceError(SERVICE)
    return response.json()
