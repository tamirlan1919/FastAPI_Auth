from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import BadRequestError
from app.core.security import hash_password
from app.db.models import User, Profile
from app.schemas.user import RegisterWithProfile
from app.services.auth_service import UserAlreadyExists


async def register_with_profile(session: AsyncSession, data: RegisterWithProfile) -> User:
    async with session.begin():
        taken = await session.scalar(
            select(User.id).where(or_(User.username == data.username, User.email == data.email))
        )
        if taken is not None:
            raise UserAlreadyExists('Пользователь с таким именем или email уже существует')

        user = User(
            username=data.username,
            email=data.email,
            hashed_password=hash_password(data.password),
            roles=['user']
        )
        session.add(user)
        await session.flush()

        if data.profile.city.lower() == 'атлантида':
            raise BadRequestError('Атлантида утонула — такого города нет')

        user.profile = Profile(
            bio=data.profile.bio,
            city=data.profile.city,
            country=data.profile.country
        )
        return user