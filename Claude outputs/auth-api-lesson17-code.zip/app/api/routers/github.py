import json

from fastapi import APIRouter, Response

from app.api.deps import RedisDep
from app.clients.github import get_user
from app.schemas.github import GithubUser

router = APIRouter(prefix="/github", tags=["github"])

GITHUB_CACHE_TTL = 600  # секунд


@router.get("/{username}", response_model=GithubUser)
async def get_github_user(username: str, redis: RedisDep, response: Response):
    key = f'github:card:{username.lower()}'

    # Смотрим в кеш
    cached = await redis.get(key)
    if cached is not None:
        response.headers['X-Cache'] = 'HIT'
        return json.loads(cached)

    # Все ошибки GitHub клиент уже превратил в наши (404/502/503/504) — try/except не нужен
    raw = await get_user(username)

    # Ответ GitHub -> только нужные поля -> JSON-строка в Redis на 10 минут
    user = GithubUser.model_validate(raw)
    await redis.set(key, user.model_dump_json(), ex=GITHUB_CACHE_TTL)

    response.headers['X-Cache'] = 'MISS'
    return user
