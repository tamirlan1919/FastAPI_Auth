"""Ошибки приложения: что случилось, какой HTTP-код и машинный code для фронтенда.

Сервисы и клиенты бросают эти исключения и ничего не знают про JSONResponse.
Превращением в ответ занимаются обработчики в app/core/error_handlers.py.
"""


class AppError(Exception):
    status_code: int = 500
    code: str = 'internal_error'
    message: str = 'Внутренняя ошибка сервера'

    def __init__(self, message: str | None = None, *, extra: dict | None = None) -> None:
        self.message = message or self.message
        self.extra = extra or {}
        super().__init__(self.message)


# --- 4xx: клиент может исправить запрос --------------------------------------
class BadRequestError(AppError):
    status_code = 400
    code = 'bad_request'
    message = 'Некорректный запрос'


class NotFoundError(AppError):
    status_code = 404
    code = 'not_found'
    message = 'Не найдено'


class ConflictError(AppError):
    status_code = 409
    code = 'conflict'
    message = 'Конфликт с текущим состоянием данных'


# --- 5xx: проблема на нашей стороне или у сервиса, от которого мы зависим ------
class ExternalServiceError(AppError):
    status_code = 502
    code = 'external_service_error'
    message = 'Внешний сервис ответил ошибкой'

    def __init__(self, service: str, message: str | None = None) -> None:
        super().__init__(message, extra={'service': service})


class ExternalServiceUnavailable(ExternalServiceError):
    status_code = 503
    code = 'external_service_unavailable'
    message = 'Внешний сервис временно недоступен, попробуйте позже'


class ExternalServiceTimeout(ExternalServiceError):
    status_code = 504
    code = 'external_service_timeout'
    message = 'Внешний сервис не ответил вовремя'
