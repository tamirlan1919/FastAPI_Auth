"""Request ID: один короткий идентификатор на запрос — в заголовке ответа, в теле ошибки и в каждой строке лога."""
import logging
import time
import uuid
from contextvars import ContextVar

from fastapi import Request

request_id_var: ContextVar[str] = ContextVar('request_id', default='-')
logger = logging.getLogger('app.access')


async def request_id_middleware(request: Request, call_next):
    # Пришёл от прокси/фронтенда — берём его, нет — создаём свой
    request_id = request.headers.get('X-Request-ID') or uuid.uuid4().hex[:12]
    request.state.request_id = request_id
    # reset не нужен: каждый запрос uvicorn обрабатывает в своей задаче asyncio со своим контекстом,
    # а обработчику 500 (он сработает уже после выхода из middleware) значение ещё понадобится
    request_id_var.set(request_id)
    started = time.perf_counter()
    status = 500
    try:
        response = await call_next(request)
        status = response.status_code
        response.headers['X-Request-ID'] = request_id
        return response
    finally:
        took = (time.perf_counter() - started) * 1000
        logger.info('%s %s → %s за %.0f мс', request.method, request.url.path, status, took)


class RequestIdFilter(logging.Filter):
    """Добавляет request_id в каждую запись лога, даже из чужих библиотек."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_var.get()
        return True


def setup_logging(level: int = logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.addFilter(RequestIdFilter())
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)-7s [%(request_id)s] %(name)s: %(message)s'))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level)
