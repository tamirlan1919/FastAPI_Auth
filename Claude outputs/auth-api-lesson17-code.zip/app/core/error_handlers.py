"""Единый формат ошибок auth-api — Problem Details (RFC 9457).

    {"type": "about:blank", "title": "Conflict", "status": 409,
     "detail": "Пользователь с таким email уже существует",
     "instance": "/auth/register", "code": "user_already_exists", "request_id": "3f9c…"}
"""
import logging
from http import HTTPStatus

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.errors import AppError

logger = logging.getLogger(__name__)


def problem(request: Request, status: int, detail: str, code: str,
            headers: dict | None = None, **extra) -> JSONResponse:
    request_id = getattr(request.state, 'request_id', None)
    body = {
        'type': 'about:blank',
        'title': HTTPStatus(status).phrase,
        'status': status,
        'detail': detail,
        'instance': request.url.path,
        'code': code,
        'request_id': request_id,
        **extra,
    }
    headers = {**(headers or {}), **({'X-Request-ID': request_id} if request_id else {})}
    return JSONResponse(body, status_code=status, headers=headers, media_type='application/problem+json')


async def app_error_handler(request: Request, exc: AppError) -> JSONResponse:
    if exc.status_code >= 500:
        # 5xx — повод разбираться: пишем в лог с причиной (__cause__ виден в traceback)
        logger.error('%s: %s %s', exc.code, exc.message, exc.extra, exc_info=exc)
    return problem(request, exc.status_code, exc.message, exc.code, **exc.extra)


async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
    # HTTPException из наших роутеров и 404/405 самого роутинга FastAPI
    detail = exc.detail if isinstance(exc.detail, str) else HTTPStatus(exc.status_code).phrase
    code = HTTPStatus(exc.status_code).name.lower()
    return problem(request, exc.status_code, detail, code, headers=exc.headers)


async def validation_error_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    # Без 'input': иначе в ответ (и в логи прокси) уходит то, что прислал клиент, включая пароль
    errors = [
        {'field': '.'.join(str(p) for p in err['loc'][1:]) or err['loc'][0], 'message': err['msg'], 'type': err['type']}
        for err in exc.errors()
    ]
    return problem(request, 422, 'Проверьте поля запроса', 'validation_error', errors=errors)


async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
    # Последняя линия обороны: клиенту — ничего лишнего, в лог — всё
    logger.exception('Необработанная ошибка: %s %s', request.method, request.url.path)
    return problem(request, 500, 'Внутренняя ошибка сервера. Сообщите request_id в поддержку', 'internal_error')


def install_error_handlers(app: FastAPI) -> None:
    app.add_exception_handler(AppError, app_error_handler)
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_error_handler)
    app.add_exception_handler(Exception, unhandled_error_handler)
