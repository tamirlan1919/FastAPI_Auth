"""Имитация GitHub REST API для урока 17 — чтобы показать ошибки чужого сервиса без интернета.

    uvicorn scripts.fake_github:app --port 9100
    curl -X POST localhost:9100/_mode/ratelimit     # normal | ratelimit | slow | down

Ответы повторяют формат настоящего GitHub (тексты сообщений — как у api.github.com).
"""
import asyncio

from fastapi import FastAPI
from fastapi.responses import JSONResponse

app = FastAPI(title='Fake GitHub')
state = {'mode': 'normal'}

USERS = {
    'octocat': {'login': 'octocat', 'id': 583231, 'name': 'The Octocat', 'company': '@github',
                'blog': 'https://github.blog', 'location': 'San Francisco', 'public_repos': 8,
                'followers': 22000, 'html_url': 'https://github.com/octocat',
                'avatar_url': 'https://avatars.githubusercontent.com/u/583231?v=4',
                'created_at': '2011-01-25T18:44:36Z'},
}


@app.post('/_mode/{mode}')
async def set_mode(mode: str):
    state['mode'] = mode
    return state


@app.get('/users/{username}')
async def get_user(username: str):
    mode = state['mode']
    if mode == 'ratelimit':
        return JSONResponse(status_code=403, headers={'X-RateLimit-Remaining': '0'}, content={
            'message': 'API rate limit exceeded for 203.0.113.7. (But here\'s the good news: Authenticated '
                       'requests get a higher rate limit. Check out the documentation for more details.)',
            'documentation_url': 'https://docs.github.com/rest/overview/resources-in-the-rest-api#rate-limiting'})
    if mode == 'slow':
        await asyncio.sleep(30)
    if mode == 'down':
        return JSONResponse(status_code=503, content={'message': 'Service Unavailable'})
    user = USERS.get(username.lower())
    if user is None:
        return JSONResponse(status_code=404, content={
            'message': 'Not Found', 'documentation_url': 'https://docs.github.com/rest/users/users#get-a-user',
            'status': '404'})
    return user
