const http = require('node:http');
const { Pool } = require('pg');

// Настройки подключения берём из переменных окружения — их передаст docker run -e
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 5432),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'pagila',
});

function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname === '/films') {
      const limit = Math.min(Number(url.searchParams.get('limit')) || 5, 50);
      const { rows } = await pool.query(
        'SELECT film_id, title, rental_rate FROM film ORDER BY film_id LIMIT $1',
        [limit],
      );
      return send(res, 200, rows);
    }
    if (url.pathname === '/health') {
      await pool.query('SELECT 1');
      return send(res, 200, { status: 'ok', db: pool.options.host });
    }
    send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('Ошибка БД:', err.message);
    send(res, 500, { error: err.message });
  }
});

server.listen(3000, () => console.log('films-api слушает порт 3000'));
