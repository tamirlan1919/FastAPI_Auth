# Скрипты первой загрузки базы

Положите сюда два файла из вашей папки pagila (той, где вы делали `docker compose up` на первом уроке):

    pagila-schema.sql  →  db/1-schema.sql
    pagila-data.sql    →  db/2-data.sql

macOS / Linux:

    cp ../pagila/pagila-schema.sql db/1-schema.sql
    cp ../pagila/pagila-data.sql   db/2-data.sql

Windows (PowerShell):

    Copy-Item ..\pagila\pagila-schema.sql db\1-schema.sql
    Copy-Item ..\pagila\pagila-data.sql   db\2-data.sql

Postgres выполнит их только при ПЕРВОМ запуске, когда том pgdata пустой.
Заново загрузить базу: docker compose down -v && docker compose up -d
