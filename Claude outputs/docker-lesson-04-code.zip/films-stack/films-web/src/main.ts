import './style.css'

type Film = { film_id: number; title: string; rental_rate: string }

// Адрес API подставляется при СБОРКЕ (vite build), а не при запуске
const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000'

const app = document.querySelector<HTMLDivElement>('#app')!
app.innerHTML = `
  <h1>🎬 Прокат Pagila</h1>
  <p class="api">API: <code>${API_URL}</code></p>
  <ul id="films"><li>Загрузка…</li></ul>
`

const list = document.querySelector<HTMLUListElement>('#films')!

fetch(`${API_URL}/films?limit=10`)
  .then((r) => r.json() as Promise<Film[]>)
  .then((films) => {
    list.innerHTML = films
      .map((f) => `<li><b>${f.title}</b> <span>${f.rental_rate} $</span></li>`)
      .join('')
  })
  .catch(() => {
    list.innerHTML = '<li class="error">API недоступен</li>'
  })
