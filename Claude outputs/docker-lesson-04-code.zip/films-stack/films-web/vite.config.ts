import { defineConfig } from 'vite'

// В режиме разработки /api проксирует сам Vite — как nginx в проде.
// Внутри compose API доступен по имени сервиса, снаружи — на localhost.
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: process.env.API_PROXY_TARGET ?? 'http://localhost:3000',
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
