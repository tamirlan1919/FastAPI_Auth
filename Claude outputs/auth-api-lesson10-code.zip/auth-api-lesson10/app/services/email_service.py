# Отправка писем. Настоящий SMTP не подключаем — имитируем его поведение:
# письмо отправляется долго (3 секунды), а иногда почтовый сервер недоступен.
import asyncio


class EmailSendError(Exception):
    pass


async def send_welcome_email(email: str, username: str) -> None:
    await asyncio.sleep(3)  # SMTP-сервер думает
    if email.startswith('fail'):  # так на уроке «роняем» почтовый сервер: fail@...  
        raise EmailSendError(f'SMTP недоступен, письмо для {email} не ушло')
    print(f'📧 Письмо «Добро пожаловать, {username}!» отправлено на {email}')
