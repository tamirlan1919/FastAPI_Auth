# Отдельный процесс-«микросервис»: слушает очередь и отправляет приветственные письма.
# Запуск из корня проекта:  python -m app.workers.email_worker
import asyncio
import json

import aio_pika
from aio_pika.abc import AbstractIncomingMessage

from app.broker.rabbit import connect_rabbit, declare_events_exchange
from app.services.email_service import send_welcome_email

QUEUE_NAME = 'email.welcome'
DLX_NAME = 'email.welcome.dlx'    # обменник для «мёртвых» сообщений
DLQ_NAME = 'email.welcome.dlq'    # очередь, где они ждут разбора


async def handle(message: AbstractIncomingMessage) -> None:
    try:
        async with message.process():           # ack после успешного блока, reject — при ошибке
            event = json.loads(message.body)
            print(f'📥 Получено событие {event["event"]} для {event["email"]}')
            await send_welcome_email(event['email'], event['username'])
    except Exception as e:
        print(f'❌ Ошибка: {e}. Сообщение отправлено в {DLQ_NAME}')


async def main() -> None:
    connection = await connect_rabbit('email-worker')
    async with connection:
        channel = await connection.channel()
        await channel.set_qos(prefetch_count=1)  # брать по одному сообщению

        # «Корзина» для сообщений, которые не удалось обработать
        dlx = await channel.declare_exchange(DLX_NAME, aio_pika.ExchangeType.FANOUT, durable=True)
        dlq = await channel.declare_queue(DLQ_NAME, durable=True)
        await dlq.bind(dlx)

        exchange = await declare_events_exchange(channel)
        queue = await channel.declare_queue(
            QUEUE_NAME,
            durable=True,
            arguments={'x-dead-letter-exchange': DLX_NAME},  # отклонённые сообщения — сюда
        )
        await queue.bind(exchange, routing_key='user.registered')

        print(f'👂 email-worker слушает очередь {QUEUE_NAME}. Остановить: Ctrl+C')
        async with queue.iterator() as messages:
            async for message in messages:
                await handle(message)


if __name__ == '__main__':
    asyncio.run(main())
