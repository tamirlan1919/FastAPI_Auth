# Второй микросервис: считает события пользователей в Redis.
# Запуск из корня проекта:  python -m app.workers.stats_worker
import asyncio

from aio_pika.abc import AbstractIncomingMessage

from app.broker.rabbit import connect_rabbit, declare_events_exchange
from app.db.redis_db import create_redis

QUEUE_NAME = 'stats.users'

redis = create_redis()


async def handle(message: AbstractIncomingMessage) -> None:
    async with message.process():
        total = await redis.incr(f'stats:{message.routing_key}')
        print(f'📊 {message.routing_key}: всего {total}')


async def main() -> None:
    connection = await connect_rabbit('stats-worker')
    async with connection:
        channel = await connection.channel()
        exchange = await declare_events_exchange(channel)
        queue = await channel.declare_queue(QUEUE_NAME, durable=True)
        await queue.bind(exchange, routing_key='user.*')   # ВСЕ события про пользователей

        print(f'👂 stats-worker слушает очередь {QUEUE_NAME}. Остановить: Ctrl+C')
        async with queue.iterator() as messages:
            async for message in messages:
                await handle(message)


if __name__ == '__main__':
    asyncio.run(main())
