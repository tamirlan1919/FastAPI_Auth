from fastapi import APIRouter

from app.api.deps import RedisDep

router = APIRouter(prefix="/stats", tags=["Статистика Redis"])

@router.get("/ping")
async def ping(redis: RedisDep):
    return {'redis': await redis.ping()}


@router.post('/visits')
async def add_visit(redis: RedisDep):
    total = await redis.incr('stats:visits')
    return {'total': total}


@router.get('/visits')
async def get_visits(redis: RedisDep):
    value = await redis.get('stats:visits')
    return {'value': value}

@router.get('/events')
async def get_events(redis: RedisDep):
    return {
        'user.registered': int(await redis.get('stats:user.registered') or 0),
        'user.logged_in': int(await redis.get('stats:user.logged_in') or 0),
    }
