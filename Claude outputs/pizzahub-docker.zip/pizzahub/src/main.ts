// Сценарий урока 2: поведенческие паттерны в PizzaHub.
import { getMenu } from './api/pizza.api';
import { addPizza, clearCart, CommandHistory } from './cart/cart.commands';
import { checkout } from './checkout/checkout.facade';
import { courier, express, pickup, quote } from './delivery/delivery.strategies';
import { registerSubscribers } from './events/subscribers';
import { paginate } from './lib/paginate';
import { notify } from './notifications/toast.factory';
import { renderHeader } from './ui/header';

registerSubscribers();                                // Observer: подписались один раз при старте
console.log('🍕 PizzaHub · урок 2\n');

// --- Iterator: меню по страницам ---
const menu = await getMenu();
let page = 1;
for (const pizzas of paginate(menu, 2)) {
  console.log(`— страница ${page++} —`);
  pizzas.forEach((p) => console.log(`   ${p.name} — ${p.price} ₽`));
}

// --- Command + Memento: корзина с отменой ---
console.log();
const history = new CommandHistory();
history.run(addPizza(menu[0], 'L', 2));
history.run(addPizza(menu[1]));
history.run(clearCart());                             // «ой, промахнулся мимо кнопки»
renderHeader();
history.undo();                                       // Ctrl+Z
renderHeader();

// --- Strategy: способы доставки ---
console.log();
for (const strategy of [courier, express, pickup]) {
  console.log(`🚚 ${quote(strategy, 900, 4)}`);
}
console.log(`🚚 ${quote(courier, 1900, 4)}   ← от 1500 ₽ курьер бесплатно`);

// --- Chain of Responsibility: ночью пиццерия закрыта ---
console.log();
await checkout({ address: 'ул. Ленина, 1', phone: '+79001234567', now: new Date('2026-10-22T03:00:00') });

// --- Facade → Chain → State → Observer: обед, всё получается ---
console.log();
const result = await checkout({
  address: 'ул. Ленина, 1',
  phone: '+79001234567',
  promoCode: 'PIZZA10',
  now: new Date('2026-10-22T13:00:00'),
});

if (result.ok) {
  const { status } = result;
  status.transition('cooking');
  status.transition('delivering');
  status.transition('delivered');
  try {
    status.transition('cancelled');                   // отменить уже доставленный? нельзя
  } catch (error) {
    notify('error', (error as Error).message);
  }
}
