// OBSERVER. Отвечает за: механизм подписки «сообщи всем, кому интересно».
// Тот, кто кричит (emit), не знает, кто его слушает (on). И это главное.

type Listener<T> = (payload: T) => void;

export class EventBus<Events extends Record<string, unknown>> {
  // для каждого события — свой список подписчиков
  private listeners: { [K in keyof Events]?: Listener<Events[K]>[] } = {};

  on<K extends keyof Events>(event: K, listener: Listener<Events[K]>): () => void {
    (this.listeners[event] ??= []).push(listener);
    return () => this.off(event, listener);          // функция «отписаться»
  }

  off<K extends keyof Events>(event: K, listener: Listener<Events[K]>): void {
    this.listeners[event] = this.listeners[event]?.filter((l) => l !== listener);
  }

  emit<K extends keyof Events>(event: K, payload: Events[K]): void {
    for (const listener of this.listeners[event] ?? []) {
      listener(payload);
    }
  }
}
