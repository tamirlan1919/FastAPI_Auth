// Подписчики. Каждый реагирует на события по-своему и ничего не знает о других.
import { notify } from '../notifications/toast.factory';
import { bus } from './app-events';

export function registerSubscribers(): void {
  // 1. Уведомление покупателю
  bus.on('order:paid', ({ orderId, total }) => {
    notify('success', `Заказ №${orderId} оплачен: ${total} ₽`);
  });

  // 2. Аналитика
  bus.on('order:paid', ({ total }) => {
    console.log(`📊 analytics: purchase, revenue=${total}`);
  });

  // 3. SMS
  bus.on('order:paid', ({ phone }) => {
    console.log(`📱 SMS на ${phone}: «Спасибо! Готовим вашу пиццу»`);
  });

  // 4. Смена статуса заказа
  bus.on('order:status', ({ orderId, from, to }) => {
    console.log(`🔔 Заказ №${orderId}: ${from} → ${to}`);
  });
}
