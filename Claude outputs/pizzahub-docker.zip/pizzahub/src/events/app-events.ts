// Каталог событий приложения: ИМЯ события → какие данные оно несёт.
// Опечатка в имени события или в поле данных — ошибка TypeScript, а не тихий баг.
import type { OrderStatus } from '../orders/order-status';
import { EventBus } from './event-bus';

export type AppEvents = {
  'order:paid': { orderId: string; total: number; phone: string };
  'order:status': { orderId: string; from: OrderStatus; to: OrderStatus };
};

// одна шина на всё приложение — Singleton из урока 1
export const bus = new EventBus<AppEvents>();
