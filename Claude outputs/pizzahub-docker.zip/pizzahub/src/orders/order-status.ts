// STATE. Отвечает за: жизненный цикл заказа. Какие статусы бывают и куда из какого можно перейти.
import { bus } from '../events/app-events';

export type OrderStatus = 'new' | 'paid' | 'cooking' | 'delivering' | 'delivered' | 'cancelled';

// Таблица переходов — вся логика статусов в одном месте
const TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  new: ['paid', 'cancelled'],
  paid: ['cooking', 'cancelled'],
  cooking: ['delivering'],
  delivering: ['delivered'],
  delivered: [],
  cancelled: [],
};

export class OrderStateMachine {
  constructor(
    public readonly orderId: string,
    private status: OrderStatus = 'new',
  ) {}

  get current(): OrderStatus {
    return this.status;
  }

  can(next: OrderStatus): boolean {
    return TRANSITIONS[this.status].includes(next);
  }

  transition(next: OrderStatus): void {
    if (!this.can(next)) {
      throw new Error(`Нельзя перейти из «${this.status}» в «${next}»`);
    }
    const from = this.status;
    this.status = next;
    bus.emit('order:status', { orderId: this.orderId, from, to: next });   // Observer!
  }
}
