// COMMAND + MEMENTO. Отвечает за: действия с корзиной как ОБЪЕКТЫ — их можно
// выполнить, записать в историю и отменить (Ctrl+Z).
import { cartStore, type CartMemento } from '../store/cart.store';
import type { Pizza, Size } from '../types';

export interface Command {
  readonly label: string;   // человекочитаемое название — для истории и логов
  execute(): void;
}

// --- фабрики команд: создают объект-команду, но НЕ выполняют её ---
export const addPizza = (pizza: Pizza, size: Size = 'M', qty = 1): Command => ({
  label: `Добавить ${pizza.name} (${size}) × ${qty}`,
  execute: () => cartStore.add(pizza, size, qty),
});

export const clearCart = (): Command => ({
  label: 'Очистить корзину',
  execute: () => cartStore.clear(),
});

// --- исполнитель с историей ---
export class CommandHistory {
  private done: { command: Command; before: CartMemento }[] = [];

  run(command: Command): void {
    const before = cartStore.snapshot();   // MEMENTO: запомнили, как было
    command.execute();
    this.done.push({ command, before });
    console.log(`▶  ${command.label}`);
  }

  undo(): boolean {
    const last = this.done.pop();
    if (!last) return false;               // отменять нечего
    cartStore.restore(last.before);        // вернули как было
    console.log(`↩  Отменено: ${last.command.label}`);
    return true;
  }

  get labels(): string[] {
    return this.done.map((entry) => entry.command.label);
  }
}
