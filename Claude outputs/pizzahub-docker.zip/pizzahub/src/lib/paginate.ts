// ITERATOR. Отвечает за: выдавать список порциями (страницами) по запросу.
// function* — генератор: функция, которая умеет «вставать на паузу» на каждом yield.

export function* paginate<T>(items: T[], pageSize: number): Generator<T[]> {
  for (let start = 0; start < items.length; start += pageSize) {
    yield items.slice(start, start + pageSize);
  }
}
