// STRATEGY. Отвечает за: способы доставки — взаимозаменяемые алгоритмы с одним интерфейсом.

export interface DeliveryStrategy {
  readonly name: string;
  price(orderTotal: number, distanceKm: number): number;
  etaMinutes(distanceKm: number): number;
}

const FREE_DELIVERY_FROM = 1500;   // ₽ — с этой суммы курьер бесплатно
const COURIER_BASE = 150;          // ₽ — базовая цена курьера
const COURIER_PER_KM = 20;         // ₽ за километр
const EXPRESS_MULTIPLIER = 2;      // экспресс вдвое дороже курьера

export const courier: DeliveryStrategy = {
  name: 'Курьер',
  price: (total, km) => (total >= FREE_DELIVERY_FROM ? 0 : COURIER_BASE + COURIER_PER_KM * km),
  etaMinutes: (km) => 30 + 4 * km,
};

export const express: DeliveryStrategy = {
  name: 'Экспресс',
  price: (_total, km) => (COURIER_BASE + COURIER_PER_KM * km) * EXPRESS_MULTIPLIER,
  etaMinutes: (km) => 15 + 2 * km,
};

export const pickup: DeliveryStrategy = {
  name: 'Самовывоз',
  price: () => 0,
  etaMinutes: () => 20,
};

// «Контекст» — код, который ПОЛЬЗУЕТСЯ стратегией и не знает, какая она
export function quote(strategy: DeliveryStrategy, orderTotal: number, distanceKm: number): string {
  const price = strategy.price(orderTotal, distanceKm);
  return `${strategy.name}: ${price === 0 ? 'бесплатно' : `${price} ₽`}, ~${strategy.etaMinutes(distanceKm)} мин`;
}
