// CHAIN OF RESPONSIBILITY. Отвечает за: прогнать заказ через цепочку проверок.
// Каждое звено решает: остановить заказ (throw) или передать дальше (await next()).
import type { CartItem } from '../../types';

export interface CheckoutContext {
  items: CartItem[];
  total: number;
  now: Date;
}

export type Middleware = (ctx: CheckoutContext, next: () => Promise<void>) => Promise<void>;

export function compose(middlewares: Middleware[]): (ctx: CheckoutContext) => Promise<void> {
  return async (ctx) => {
    const run = async (index: number): Promise<void> => {
      const middleware = middlewares[index];
      if (!middleware) return;                           // цепочка закончилась
      await middleware(ctx, () => run(index + 1));       // next = «запусти следующее звено»
    };
    await run(0);
  };
}
