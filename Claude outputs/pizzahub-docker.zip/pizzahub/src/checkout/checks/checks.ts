// Звенья цепочки. Каждое — маленькая функция с ОДНОЙ проверкой.
import type { Middleware } from './pipeline';

const OPEN_HOUR = 10;          // пиццерия открывается в 10:00
const CLOSE_HOUR = 23;         // и закрывается в 23:00
const MAX_PIZZAS = 20;         // больше — это уже банкет, оформляется через менеджера
const MANUAL_REVIEW_FROM = 5000; // ₽ — крупные заказы подтверждает оператор

export const logTiming: Middleware = async (ctx, next) => {
  const start = performance.now();
  console.log('🔍 проверки: старт');
  await next();                                        // ← все остальные звенья выполняются ЗДЕСЬ
  console.log(`🔍 проверки: пройдены за ${Math.round(performance.now() - start)} мс`);
};

export const cartNotEmpty: Middleware = async (ctx, next) => {
  if (ctx.items.length === 0) throw new Error('Корзина пуста');
  await next();
};

export const workingHours: Middleware = async (ctx, next) => {
  const hour = ctx.now.getHours();
  if (hour < OPEN_HOUR || hour >= CLOSE_HOUR) {
    throw new Error(`Пиццерия работает с ${OPEN_HOUR}:00 до ${CLOSE_HOUR}:00`);
  }
  await next();
};

export const maxPizzas: Middleware = async (ctx, next) => {
  const count = ctx.items.reduce((sum, item) => sum + item.qty, 0);
  if (count > MAX_PIZZAS) throw new Error(`Не больше ${MAX_PIZZAS} пицц в одном заказе`);
  await next();
};

export const manualReview: Middleware = async (ctx, next) => {
  if (ctx.total >= MANUAL_REVIEW_FROM) {
    throw new Error('Крупный заказ: с вами свяжется оператор для подтверждения');
  }
  await next();
};
