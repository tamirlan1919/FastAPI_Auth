// Имитация платёжного сервиса. Отвечает за: «списать» деньги или отказать.
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const BANK_DELAY_MS = 200;        // имитация ответа банка
const CARD_BALANCE_RUB = 5000;    // столько «денег» на тестовой карте

export async function payWithCard(amount: number): Promise<string> {
  await sleep(BANK_DELAY_MS);
  if (amount > CARD_BALANCE_RUB) throw new Error('Банк отклонил платёж: недостаточно средств');
  return `pay_${Date.now()}`;
}
