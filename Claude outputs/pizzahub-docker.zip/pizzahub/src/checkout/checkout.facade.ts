// FACADE (урок 1) — теперь внутри работают ещё и паттерны урока 2:
// Chain of Responsibility (проверки), State (статус заказа), Observer (события).
import { bus } from '../events/app-events';
import { notify } from '../notifications/toast.factory';
import { OrderBuilder } from '../orders/order.builder';
import { OrderStateMachine } from '../orders/order-status';
import { calcTotal } from '../pricing';
import { cartStore } from '../store/cart.store';
import type { Order } from '../types';
import { cartNotEmpty, logTiming, manualReview, maxPizzas, workingHours } from './checks/checks';
import { compose } from './checks/pipeline';
import { payWithCard } from './payment';

// цепочку собираем один раз; порядок звеньев = порядок проверок
const runChecks = compose([logTiming, cartNotEmpty, workingHours, maxPizzas, manualReview]);

export interface CheckoutInput {
  address: string;
  phone: string;
  promoCode?: string;
  now?: Date;            // «который час» — можно подставить в тестах
}

export type CheckoutResult =
  | { ok: true; order: Order; status: OrderStateMachine; paymentId: string }
  | { ok: false; error: string };

export async function checkout(input: CheckoutInput): Promise<CheckoutResult> {
  try {
    const items = cartStore.getItems();
    const promoCode = input.promoCode ?? null;
    await runChecks({ items, total: calcTotal(items, promoCode), now: input.now ?? new Date() });

    const order = new OrderBuilder()
      .fromCart(items)
      .to(input.address)
      .withPhone(input.phone)
      .withPromo(promoCode)
      .build();

    const status = new OrderStateMachine(order.id);       // статус «new»
    const paymentId = await payWithCard(order.total);
    status.transition('paid');
    cartStore.clear();

    bus.emit('order:paid', { orderId: order.id, total: order.total, phone: order.phone });
    return { ok: true, order, status, paymentId };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    notify('error', `Заказ не оформлен: ${message}`);
    return { ok: false, error: message };
  }
}
