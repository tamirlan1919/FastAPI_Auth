from datetime import datetime

from pydantic import BaseModel, Field, HttpUrl


# --- то, что ПРИХОДИТ от GitHub (описываем только нужные нам поля) ---

class GitHubUser(BaseModel):
    login: str
    name: str | None = None
    avatar_url: HttpUrl
    html_url: HttpUrl
    public_repos: int
    followers: int
    created_at: datetime


class GitHubRepo(BaseModel):
    name: str
    html_url: HttpUrl
    description: str | None = None
    language: str | None = None
    stars: int = Field(validation_alias='stargazers_count')
    fork: bool


# --- то, что МЫ отдаём фронтенду ---

class RepoOut(BaseModel):
    name: str
    html_url: HttpUrl
    description: str | None
    language: str | None
    stars: int


class GitHubCard(BaseModel):
    login: str
    name: str | None
    avatar_url: HttpUrl
    html_url: HttpUrl
    public_repos: int
    followers: int
    member_since: int                 # год регистрации на GitHub
    top_repos: list[RepoOut]
