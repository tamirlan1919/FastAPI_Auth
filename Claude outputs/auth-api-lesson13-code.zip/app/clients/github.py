import asyncio
import logging

import httpx
from pydantic import TypeAdapter, ValidationError

from app.shemas.github import GitHubRepo, GitHubUser

logger = logging.getLogger(__name__)

repos_adapter = TypeAdapter(list[GitHubRepo])


class GitHubError(Exception):
    """Любая проблема при работе с GitHub."""


class GitHubNotFound(GitHubError):
    """Такого пользователя на GitHub нет."""


class GitHubRateLimited(GitHubError):
    """Исчерпан лимит запросов."""

    def __init__(self, reset_at: int):
        super().__init__(f'Лимит запросов исчерпан до {reset_at}')
        self.reset_at = reset_at          # unix-время, когда лимит обновится


class GitHubUnavailable(GitHubError):
    """GitHub не отвечает: таймаут, нет сети, ошибка 5xx."""


class GitHubClient:
    def __init__(
        self,
        base_url: str = 'https://api.github.com',
        token: str | None = None,
        timeout: float = 5.0,
        retries: int = 2,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self.retries = retries
        headers = {
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28',
            'User-Agent': 'auth-api',
        }
        if token:
            headers['Authorization'] = f'Bearer {token}'

        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _get(self, path: str, params: dict | None = None):
        for attempt in range(self.retries + 1):
            try:
                return await self._get_once(path, params)
            except GitHubUnavailable as exc:
                if attempt == self.retries:
                    raise
                delay = 0.5 * 2 ** attempt               # 0.5 с, 1 с, 2 с ...
                logger.warning('Попытка %s: %s. Повтор через %s с', attempt + 1, exc, delay)
                await asyncio.sleep(delay)

    async def _get_once(self, path: str, params: dict | None = None):
        try:
            response = await self._client.get(path, params=params)
        except httpx.TimeoutException as exc:
            raise GitHubUnavailable('GitHub не ответил вовремя') from exc
        except httpx.TransportError as exc:
            raise GitHubUnavailable(f'Нет связи с GitHub: {exc!r}') from exc

        remaining = response.headers.get('x-ratelimit-remaining')
        logger.info('GitHub %s %s → %s, осталось запросов: %s',
                    response.request.method, path, response.status_code, remaining)

        if response.status_code == 404:
            raise GitHubNotFound(path)
        if response.status_code in (403, 429) and remaining == '0':
            raise GitHubRateLimited(int(response.headers.get('x-ratelimit-reset', 0)))
        if response.status_code >= 500:
            raise GitHubUnavailable(f'GitHub ответил {response.status_code}')
        if response.is_error:
            # 401, 422 и т. п. — ошибка в НАШЕМ запросе или токене. Клиенту её не показываем
            logger.error('GitHub отклонил запрос %s: %s %s',
                         path, response.status_code, response.text[:200])
            raise GitHubError(f'GitHub ответил {response.status_code}')
        return response.json()

    async def get_user(self, login: str) -> GitHubUser:
        data = await self._get(f'/users/{login}')
        try:
            return GitHubUser.model_validate(data)
        except ValidationError as exc:
            logger.error('GitHub прислал неожиданный ответ: %s', exc)
            raise GitHubError('Неожиданный формат ответа GitHub') from exc

    async def get_repos(self, login: str) -> list[GitHubRepo]:
        data = await self._get(f'/users/{login}/repos', params={'per_page': 100, 'sort': 'pushed'})
        try:
            return repos_adapter.validate_python(data)
        except ValidationError as exc:
            logger.error('GitHub прислал неожиданный ответ: %s', exc)
            raise GitHubError('Неожиданный формат ответа GitHub') from exc
