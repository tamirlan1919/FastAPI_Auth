import time

from fastapi import APIRouter, HTTPException, Response, status

from app.api.deps import GitHubDep, RedisDep
from app.clients.github import GitHubError, GitHubNotFound, GitHubRateLimited, GitHubUnavailable
from app.shemas.github import GitHubCard, RepoOut

router = APIRouter(prefix='/github', tags=['GitHub'])

CARD_TTL = 600  # 10 минут


@router.get('/{login}', response_model=GitHubCard)
async def github_card(login: str, github: GitHubDep, redis: RedisDep, response: Response):
    key = f'github:card:{login.lower()}'
    cached = await redis.get(key)
    if cached is not None:
        response.headers['X-Cache'] = 'HIT'
        return GitHubCard.model_validate_json(cached)

    try:
        user = await github.get_user(login)
        repos = await github.get_repos(login)
    except GitHubNotFound:
        raise HTTPException(status.HTTP_404_NOT_FOUND, 'Пользователь GitHub не найден')
    except GitHubRateLimited as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            'GitHub временно ограничил запросы, попробуйте позже',
            headers={'Retry-After': str(max(exc.reset_at - int(time.time()), 1))},
        )
    except GitHubUnavailable:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, 'GitHub временно недоступен')
    except GitHubError:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, 'Ошибка при обращении к GitHub')

    top = sorted((r for r in repos if not r.fork), key=lambda r: r.stars, reverse=True)[:3]
    card = GitHubCard(
        login=user.login,
        name=user.name,
        avatar_url=user.avatar_url,
        html_url=user.html_url,
        public_repos=user.public_repos,
        followers=user.followers,
        member_since=user.created_at.year,
        top_repos=[RepoOut(**repo.model_dump(exclude={'fork'})) for repo in top],
    )
    await redis.set(key, card.model_dump_json(), ex=CARD_TTL)
    response.headers['X-Cache'] = 'MISS'
    return card
