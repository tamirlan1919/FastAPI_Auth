import asyncio
import time

import httpx

URL = 'https://api.github.com/users/octocat'


async def new_client_each_time(n: int):
    for _ in range(n):
        async with httpx.AsyncClient() as client:   # новое соединение, новый TLS-handshake
            await client.get(URL)


async def one_shared_client(n: int):
    async with httpx.AsyncClient() as client:       # соединение переиспользуется
        for _ in range(n):
            await client.get(URL)


async def main():
    for func in (new_client_each_time, one_shared_client):
        start = time.perf_counter()
        await func(5)
        print(f'{func.__name__:22} 5 запросов: {time.perf_counter() - start:.2f} с')


if __name__ == '__main__':
    asyncio.run(main())
