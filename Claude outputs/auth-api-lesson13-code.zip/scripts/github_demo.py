import asyncio
import time

import httpx

LOGINS = ['tiangolo', 'octocat', 'gvanrossum', 'torvalds', 'samuelcolvin']


def sync_demo():
    response = httpx.get('https://api.github.com/users/tiangolo')
    print('Статус:', response.status_code, response.headers['content-type'])
    print('Лимит:', response.headers['x-ratelimit-limit'],
          'осталось:', response.headers['x-ratelimit-remaining'])
    data = response.json()                      # JSON → dict
    print(data['name'], '| репозиториев:', data['public_repos'], '| подписчиков:', data['followers'])


async def fetch_login(client: httpx.AsyncClient, login: str) -> str:
    response = await client.get(f'/users/{login}')
    return response.json()['login']


async def async_demo():
    async with httpx.AsyncClient(base_url='https://api.github.com') as client:
        start = time.perf_counter()
        for login in LOGINS:
            await fetch_login(client, login)
        print(f'По очереди: {time.perf_counter() - start:.2f} с')

        start = time.perf_counter()
        result = await asyncio.gather(*(fetch_login(client, login) for login in LOGINS))
        print(f'Параллельно (gather): {time.perf_counter() - start:.2f} с', result)


if __name__ == '__main__':
    sync_demo()
    asyncio.run(async_demo())
