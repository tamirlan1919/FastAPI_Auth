import asyncio
import logging

from app.clients.github import GitHubClient, GitHubError

logging.basicConfig(level=logging.INFO, format='%(levelname)s %(name)s: %(message)s')
logging.getLogger('httpx').setLevel(logging.WARNING)


async def main():
    github = GitHubClient()
    try:
        user = await github.get_user('tiangolo')
        print(repr(user))
        for login in ['no-such-user-zzz-13']:
            try:
                await github.get_user(login)
            except GitHubError as exc:
                print(type(exc).__name__, '→', exc)
    finally:
        await github.aclose()

    slow = GitHubClient(timeout=0.001)
    try:
        await slow.get_user('tiangolo')
    except GitHubError as exc:
        print(type(exc).__name__, '→', exc, '| причина:', type(exc.__cause__).__name__)
    finally:
        await slow.aclose()


if __name__ == '__main__':
    asyncio.run(main())
