import httpx
import pytest

from app.clients.github import (
    GitHubClient, GitHubError, GitHubNotFound, GitHubRateLimited, GitHubUnavailable,
)

USER_JSON = {
    'login': 'octocat', 'name': 'The Octocat', 'public_repos': 8, 'followers': 22000,
    'avatar_url': 'https://avatars.githubusercontent.com/u/583231?v=4',
    'html_url': 'https://github.com/octocat',
    'created_at': '2011-01-25T18:44:36Z',
    'node_id': 'лишнее поле — модель его проигнорирует',
}


def make_client(handler) -> GitHubClient:
    """Клиент, который вместо интернета вызывает нашу функцию handler."""
    return GitHubClient(transport=httpx.MockTransport(handler), retries=1)


async def test_get_user_ok():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == '/users/octocat'
        assert request.headers['X-GitHub-Api-Version'] == '2022-11-28'
        return httpx.Response(200, json=USER_JSON)

    github = make_client(handler)
    user = await github.get_user('octocat')
    assert user.login == 'octocat'
    assert user.created_at.year == 2011


async def test_not_found():
    github = make_client(lambda request: httpx.Response(404, json={'message': 'Not Found'}))
    with pytest.raises(GitHubNotFound):
        await github.get_user('nobody')


async def test_rate_limited():
    def handler(request):
        return httpx.Response(403, headers={'x-ratelimit-remaining': '0',
                                            'x-ratelimit-reset': '1793983547'})

    github = make_client(handler)
    with pytest.raises(GitHubRateLimited) as exc_info:
        await github.get_user('octocat')
    assert exc_info.value.reset_at == 1793983547


async def test_retry_after_500_then_ok():
    calls = []

    def handler(request):
        calls.append(request)
        if len(calls) == 1:
            return httpx.Response(502)
        return httpx.Response(200, json=USER_JSON)

    user = await make_client(handler).get_user('octocat')
    assert user.login == 'octocat'
    assert len(calls) == 2            # первая попытка упала, вторая прошла


async def test_timeout_gives_up_after_retries():
    calls = []

    def handler(request):
        calls.append(request)
        raise httpx.ConnectTimeout('timeout', request=request)

    with pytest.raises(GitHubUnavailable):
        await make_client(handler).get_user('octocat')
    assert len(calls) == 2            # 1 попытка + 1 повтор


async def test_bad_token_is_not_forwarded():
    github = make_client(lambda request: httpx.Response(401, json={'message': 'Bad credentials'}))
    with pytest.raises(GitHubError) as exc_info:
        await github.get_user('octocat')
    assert type(exc_info.value) is GitHubError       # не NotFound, не RateLimited


async def test_changed_response_format():
    broken = {**USER_JSON, 'public_repos': 'много'}
    github = make_client(lambda request: httpx.Response(200, json=broken))
    with pytest.raises(GitHubError, match='Неожиданный формат'):
        await github.get_user('octocat')
