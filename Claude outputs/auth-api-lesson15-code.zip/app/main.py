import logging
from asyncio import ensure_future

import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from prometheus_fastapi_instrumentator import Instrumentator
from app.api.routers import users, auth, todos, stats, posts, reports, github, weather, yandex_auth, telegram
from app.bot.setup import BOT_COMMANDS, create_bot, create_dispatcher
from app.clients.yandex_oauth import YandexOauthClient
from app.core.config import settings
from app.db.database import Base, engine
from app.db import models  # noqa: F401 — регистрирует модели в Base.metadata для create_all
from contextlib import asynccontextmanager
from app.db.redis_db import create_redis
from app.broker.rabbit import connect_rabbit, declare_events_exchange, EventPublisher


logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.redis = create_redis()
    await app.state.redis.ping()

    app.state.rabbit = await connect_rabbit('auth-api')
    channel = await app.state.rabbit.channel()
    exchange = await declare_events_exchange(channel)
    app.state.publisher = EventPublisher(exchange)
    app.state.yandex_oauth = app.state.yandex_disk = None
    if settings.yandex_client_id and settings.yandex_client_secret:
        app.state.yandex_oauth = YandexOauthClient(
            client_id=settings.yandex_client_id,
            client_secret=settings.yandex_client_secret.get_secret_value(),
            redirect_uri=settings.yandex_redirect_uri,
            oauth_url=settings.yandex_oauth_url,
            login_url=settings.yandex_login_url,
        )

    app.state.bot = app.state.dp = None
    if settings.telegram_bot_token:
        bot = create_bot(settings.telegram_bot_token.get_secret_value(), settings.telegram_api_url)
        dp = create_dispatcher(redis=app.state.redis)
        app.state.bot, app.state.dp = bot, dp
        await bot.set_my_commands(BOT_COMMANDS)
        if settings.telegram_webhook_base:
            if settings.telegram_webhook_secret is None:
                raise RuntimeError('TELEGRAM_WEBHOOK_SECRET обязателен, если задан TELEGRAM_WEBHOOK_BASE')
            await bot.set_webhook(
                url=f'{settings.telegram_webhook_base}/telegram/webhook',
                secret_token=settings.telegram_webhook_secret.get_secret_value(),
                allowed_updates=dp.resolve_used_update_types(),
            )
            logger.info('Вебхук Telegram: %s/telegram/webhook', settings.telegram_webhook_base)



    yield
    await app.state.rabbit.close()
    await app.state.redis.aclose()
    for client in (app.state.yandex_oauth, app.state.yandex_disk):
        if client is not None:
            await client.aclose()
    if app.state.bot is not None:
        # вебхук НЕ удаляем: при перезапуске/выкатке Telegram копит апдейты и отдаст их новой версии
        await app.state.bot.session.close()




app = FastAPI(lifespan=lifespan)
app.include_router(users.router)
app.include_router(auth.router)
app.include_router(todos.router)
app.include_router(stats.router)
app.include_router(posts.router)
app.include_router(reports.router)
app.include_router(github.router)
app.include_router(weather.router)
app.include_router(yandex_auth.router)
app.include_router(telegram.router)

# Prometheus: middleware считает запросы/латентность, GET /metrics отдаёт их в формате Prometheus
Instrumentator(
    should_group_status_codes=False,         # status="404", а не "4xx"
    should_ignore_untemplated=True,          # не плодим метрики на несуществующие пути (сканеры, опечатки)
    should_instrument_requests_inprogress=True,
    inprogress_labels=True,
    excluded_handlers=["/metrics"],
).instrument(app).expose(app, include_in_schema=False)


@app.get("/")
async def root():
    return {"message": "Hello World"}


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)



if __name__ == '__main__':
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)