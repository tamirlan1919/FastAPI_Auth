from aiogram.filters import Filter
from aiogram.types import Message

from app.db.models import User


class LinkedUser(Filter):
    """Пропускает только сообщения от тех, кто привязал Telegram к auth-api."""

    async def __call__(self, message: Message, user: User | None) -> bool:
        return user is not None
