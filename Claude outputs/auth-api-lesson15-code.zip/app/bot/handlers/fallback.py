from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router(name='fallback')


@router.message(Command('me', 'posts', 'unlink'))
async def not_linked(message: Message) -> None:
    # Сюда попадаем, только если LinkedUser в account.router сказал «нет»
    await message.answer('Аккаунт не привязан. Получите ссылку в профиле auth-api и откройте её.')


@router.message()
async def unknown(message: Message) -> None:
    await message.answer('Не понял 🤔 Команды: /me /posts /unlink')
