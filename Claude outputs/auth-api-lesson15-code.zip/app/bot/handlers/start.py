import logging

from aiogram import Router, html
from aiogram.filters import CommandObject, CommandStart
from aiogram.types import Message
from redis.asyncio import Redis

from app.bot.links import link_key
from app.db.models import User
from app.repositories.user_repo import UserRepo

logger = logging.getLogger(__name__)
router = Router(name='start')


@router.message(CommandStart(deep_link=True))
async def start_with_code(
    message: Message,
    command: CommandObject,
    redis: Redis,
    user_repo: UserRepo,
    user: User | None,
) -> None:
    # GETDEL: прочитать и сразу удалить — второй раз по той же ссылке не войти
    user_id = await redis.getdel(link_key(command.args))
    if user_id is None:
        await message.answer('Ссылка устарела или уже использована. Получите новую в профиле auth-api.')
        return

    if user is not None:
        await message.answer(
            f'Этот Telegram уже привязан к {html.bold(html.quote(user.username))}. '
            f'Сначала /unlink.'
        )
        return

    target = await user_repo.get_by_id(int(user_id))
    if target is None:
        await message.answer('Аккаунт не найден — возможно, его удалили.')
        return

    await user_repo.set_telegram_id(target, message.from_user.id)
    logger.info('Telegram %s привязан к user_id=%s', message.from_user.id, target.id)
    await message.answer(
        f'Готово! Telegram привязан к аккаунту {html.bold(html.quote(target.username))}.\n'
        f'Попробуйте /me и /posts'
    )


@router.message(CommandStart())
async def start_plain(message: Message, user: User | None) -> None:
    if user is not None:
        await message.answer(f'С возвращением, {html.bold(html.quote(user.username))}! Команды: /me /posts /unlink')
        return
    await message.answer(
        'Привет! Я бот auth-api.\n'
        'Чтобы привязать аккаунт, войдите на сайт и нажмите «Подключить Telegram» '
        f'(или вызовите {html.code("POST /telegram/link")}).'
    )
