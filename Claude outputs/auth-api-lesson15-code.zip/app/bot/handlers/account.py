from aiogram import Router, html
from aiogram.filters import Command
from aiogram.types import Message

from app.bot.filters import LinkedUser
from app.db.models import User
from app.repositories.post_repo import PostRepo
from app.repositories.user_repo import UserRepo

router = Router(name='account')
router.message.filter(LinkedUser())   # фильтр на весь роутер: чужих сюда не пускаем

POSTS_LIMIT = 10


@router.message(Command('me'))
async def me(message: Message, user: User) -> None:
    roles = ', '.join(user.roles) or '—'
    await message.answer(
        f'👤 {html.bold(html.quote(user.username))}\n'
        f'📧 {html.quote(user.email)}\n'
        f'🔑 роли: {html.quote(roles)}\n'
        f'📅 с нами с {user.created_at:%d.%m.%Y}'
    )


@router.message(Command('posts'))
async def my_posts(message: Message, user: User, post_repo: PostRepo) -> None:
    posts = await post_repo.get_by_author(user.id)
    if not posts:
        await message.answer('У вас пока нет постов.')
        return
    lines = []
    for post in posts[:POSTS_LIMIT]:
        line = f'• {html.quote(post.title)}'
        if post.tags:
            line += ' ' + html.italic(html.quote(' '.join(f'#{tag.name}' for tag in post.tags)))
        lines.append(line)
    more = f'\n…и ещё {len(posts) - POSTS_LIMIT}' if len(posts) > POSTS_LIMIT else ''
    await message.answer(f'📝 Ваши посты ({len(posts)}):\n' + '\n'.join(lines) + more)


@router.message(Command('unlink'))
async def unlink(message: Message, user: User, user_repo: UserRepo) -> None:
    await user_repo.set_telegram_id(user, None)
    await message.answer('Telegram отвязан. Чтобы подключить снова — новая ссылка из профиля.')
