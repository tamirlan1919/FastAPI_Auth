from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.repositories.post_repo import PostRepo
from app.repositories.user_repo import UserRepo

Handler = Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]]


class DbSessionMiddleware(BaseMiddleware):
    """Одна сессия БД на один апдейт — как Depends(get_async_session) на один запрос."""

    def __init__(self, session_maker: async_sessionmaker) -> None:
        self.session_maker = session_maker

    async def __call__(self, handler: Handler, event: TelegramObject, data: dict[str, Any]) -> Any:
        async with self.session_maker() as session:
            data['user_repo'] = UserRepo(session)
            data['post_repo'] = PostRepo(session)
            return await handler(event, data)


class CurrentUserMiddleware(BaseMiddleware):
    """Кладёт в data['user'] пользователя auth-api, к которому привязан этот Telegram (или None)."""

    async def __call__(self, handler: Handler, event: TelegramObject, data: dict[str, Any]) -> Any:
        tg_user = data.get('event_from_user')
        user_repo: UserRepo = data['user_repo']
        data['user'] = await user_repo.get_by_telegram_id(tg_user.id) if tg_user else None
        return await handler(event, data)
