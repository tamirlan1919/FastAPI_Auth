import os

from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

# On macOS billiard starts prefork children via spawn instead of fork. Without this
# flag Celery skips initializing them and every task fails with
# "ValueError: not enough values to unpack (expected 3, got 0)".
os.environ.setdefault('FORKED_BY_MULTIPROCESSING', '1')

celery_app = Celery(
    'auth-api',
    broker=settings.rabbit_url,
    backend=settings.celery_result_backend,
    include=['app.tasks.demo', 'app.tasks.reports']
)


celery_app.conf.update(
    task_track_started=True,
    result_expires=3600,
    timezone ='UTC',
    # RabbitMQ 4.x denies transient non-exclusive queues (transient_nonexcl_queues),
    # so Celery's pidbox (mingle/inspect) and gossip queues must be exclusive.
    control_queue_exclusive=True,
    event_queue_exclusive=True,
)

celery_app.conf.beat_schedule = {
    'send-report-every-morning': {
        'task': 'app.tasks.reports',
        'schedule': crontab(hour=21, minute=38), # Каждый день в 21:38
    },
}