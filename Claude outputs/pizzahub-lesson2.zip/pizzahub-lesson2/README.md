# PizzaHub — после урока 2 «Поведенческие паттерны и антипаттерны»

Нужен Node.js 20+.

    npm install
    npm run dev        # сценарий урока 2
    npm run typecheck  # проверка типов

| Паттерн                 | Файл                                         |
|-------------------------|----------------------------------------------|
| Observer                | src/events/event-bus.ts, subscribers.ts      |
| Strategy                | src/delivery/delivery.strategies.ts          |
| State                   | src/orders/order-status.ts                   |
| Command + Memento       | src/cart/cart.commands.ts, store/cart.store.ts |
| Iterator                | src/lib/paginate.ts                          |
| Chain of Responsibility | src/checkout/checks/                         |
| Facade (обновлён)       | src/checkout/checkout.facade.ts              |

Паттерны урока 1 (Singleton, Factory, Builder, Prototype, Adapter, Decorator, Proxy) остались на своих местах.
