import secrets

from app.core.security import hash_password
from app.db.models import User
from app.repositories.user_repo import UserRepo
from app.shemas.yandex import YandexProfile


class YandexEmailRequired(Exception):
    """У приложения нет права login:email или у аккаунта нет почты."""


async def login_or_register(user_repo: UserRepo, profile: YandexProfile) -> User:
    if not profile.default_email:
        raise YandexEmailRequired('Яндекс не передал email')

    email = profile.default_email.lower()
    user = await user_repo.get_by_email(email)
    if user is not None:
        return user                       # уже регистрировался — просто входит

    username = profile.login
    if await user_repo.get_by_username(username) is not None:
        username = f'{profile.login}_ya{profile.id[-4:]}'   # логин занят другим человеком

    return await user_repo.create(
        username=username,
        email=email,
        # пароля у такого пользователя нет: кладём хеш случайной строки, войти по паролю нельзя
        hashed_password=hash_password(secrets.token_urlsafe(32)),
        roles=['user'],
    )
