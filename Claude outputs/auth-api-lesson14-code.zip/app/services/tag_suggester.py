import json
import logging
import re

from pydantic import TypeAdapter

from app.clients.yandex_gpt import YandexGPTClient, YandexGPTError

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    'Ты помогаешь вести технический блог. По заголовку поста предложи от 1 до 5 тегов. '
    'Теги — короткие, на английском, в нижнем регистре, без #. '
    'Ответь ТОЛЬКО JSON-массивом строк, без пояснений. Пример: ["python", "fastapi"]'
)

tags_adapter = TypeAdapter(list[str])


def parse_tags(text: str) -> list[str]:
    """Модель может обернуть ответ в ```json ... ``` — вырезаем массив и проверяем Pydantic."""
    match = re.search(r'\[.*?\]', text, re.DOTALL)
    if not match:
        raise ValueError(f'В ответе нет JSON-массива: {text[:100]!r}')
    tags = tags_adapter.validate_python(json.loads(match.group()))
    clean = [t.strip().lower().lstrip('#') for t in tags if t.strip()]
    return list(dict.fromkeys(clean))[:5]          # без дублей, не больше 5


async def suggest_tags(gpt: YandexGPTClient, title: str) -> tuple[list[str], str]:
    try:
        text = await gpt.complete(SYSTEM_PROMPT, title)
        return parse_tags(text), 'yandexgpt'
    except (YandexGPTError, ValueError) as exc:   # ValidationError и JSONDecodeError — тоже ValueError
        logger.warning('Теги не получены, отдаём запасной вариант: %s', exc)
        words = re.findall(r'[a-zA-Z]{3,}', title.lower())          # простая эвристика
        return list(dict.fromkeys(words))[:3], 'fallback'
