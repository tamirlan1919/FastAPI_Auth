from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    secret_key: str
    algorithm: str = 'HS256'
    access_token_expire_minutes: int = 30

    model_config = SettingsConfigDict(env_file=BASE_DIR / '.env', env_file_encoding='utf-8')

    mongo_url: str = 'mongodb://localhost:27017'
    mongo_db: str = 'test_db'

    redis_url: str = 'redis://localhost:6379/0'
    cache_ttl: int = 60

    rabbit_url: str = 'amqp://guest:guest@localhost:5672/'

    celery_result_backend: str = 'redis://localhost:6379/1'

    github_api_url: str = 'https://api.github.com'
    github_token: SecretStr | None = None
    github_timeout: float = 3.0
    github_retries: int = 1

    # Яндекс ID (oauth.yandex.ru → «Создать приложение»)
    yandex_client_id: str | None = None
    yandex_client_secret: SecretStr | None = None
    yandex_redirect_uri: str = 'http://localhost:8000/auth/yandex/callback'
    yandex_oauth_url: str = 'https://oauth.yandex.ru'
    yandex_login_url: str = 'https://login.yandex.ru'

    # Яндекс Диск (OAuth-токен владельца диска с правами cloud_api:disk.*)
    yandex_disk_token: SecretStr | None = None
    yandex_disk_url: str = 'https://cloud-api.yandex.net'

    # YandexGPT (Yandex Cloud: API-ключ сервисного аккаунта + id каталога)
    yandex_gpt_api_key: SecretStr | None = None
    yandex_folder_id: str | None = None
    yandex_gpt_url: str = 'https://llm.api.cloud.yandex.net'

settings = Settings()
