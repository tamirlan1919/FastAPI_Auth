import logging
from urllib.parse import urlencode

import httpx

from app.shemas.yandex import YandexProfile, YandexToken

logger = logging.getLogger(__name__)


class YandexOAuthError(Exception):
    """Яндекс отказал: неверный код, протухший токен, недоступен сервер."""


class YandexOAuthClient:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        redirect_uri: str,
        oauth_url: str = 'https://oauth.yandex.ru',
        login_url: str = 'https://login.yandex.ru',
        timeout: float = 5.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.oauth_url = oauth_url
        self.login_url = login_url
        self._client = httpx.AsyncClient(timeout=timeout, transport=transport)

    async def aclose(self) -> None:
        await self._client.aclose()

    def authorize_url(self, state: str) -> str:
        """Шаг 1: куда отправить браузер пользователя."""
        params = {
            'response_type': 'code',
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'state': state,
        }
        return f'{self.oauth_url}/authorize?{urlencode(params)}'

    async def exchange_code(self, code: str) -> YandexToken:
        """Шаг 3: обменять одноразовый код на access_token (сервер → Яндекс)."""
        try:
            response = await self._client.post(
                f'{self.oauth_url}/token',
                data={
                    'grant_type': 'authorization_code',
                    'code': code,
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                },
            )
        except httpx.TransportError as exc:
            raise YandexOAuthError(f'Яндекс OAuth недоступен: {exc!r}') from exc

        if response.status_code != 200:
            # {"error": "invalid_grant", "error_description": "Code has expired"}
            logger.warning('Обмен кода не удался: %s %s', response.status_code, response.text[:200])
            raise YandexOAuthError(response.json().get('error_description', 'unknown error'))
        return YandexToken.model_validate(response.json())

    async def get_profile(self, access_token: str) -> YandexProfile:
        """Шаг 4: кто этот пользователь."""
        try:
            response = await self._client.get(
                f'{self.login_url}/info',
                params={'format': 'json'},
                headers={'Authorization': f'OAuth {access_token}'},   # именно OAuth, а не Bearer
            )
        except httpx.TransportError as exc:
            raise YandexOAuthError(f'Яндекс ID недоступен: {exc!r}') from exc

        if response.status_code != 200:
            logger.warning('Профиль не получен: %s %s', response.status_code, response.text[:200])
            raise YandexOAuthError(f'login.yandex.ru ответил {response.status_code}')
        return YandexProfile.model_validate(response.json())
