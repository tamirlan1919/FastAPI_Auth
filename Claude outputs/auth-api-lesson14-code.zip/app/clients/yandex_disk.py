import asyncio
import logging
from pathlib import Path

import httpx

from app.shemas.yandex import DiskLink

logger = logging.getLogger(__name__)


class YandexDiskError(Exception):
    pass


class YandexDiskClient:
    def __init__(
        self,
        token: str,
        base_url: str = 'https://cloud-api.yandex.net',
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self._auth = {'Authorization': f'OAuth {token}'}
        self._client = httpx.AsyncClient(
            base_url=f'{base_url}/v1/disk',
            timeout=timeout,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _request(self, method: str, url: str, auth: bool = True, **kwargs) -> httpx.Response:
        headers = self._auth if auth else {}
        try:
            response = await self._client.request(method, url, headers=headers, **kwargs)
        except httpx.TransportError as exc:
            raise YandexDiskError(f'Диск недоступен: {exc!r}') from exc
        logger.info('Диск %s %s → %s', method, url, response.status_code)
        return response

    async def ensure_folder(self, path: str) -> None:
        """Создать папку. 409 — «уже есть», для нас это успех."""
        response = await self._request('PUT', '/resources', params={'path': path})
        if response.status_code not in (201, 409):
            raise YandexDiskError(f'Не удалось создать папку: {response.status_code} {response.text[:200]}')

    async def upload(self, local_path: Path, disk_path: str) -> None:
        """Загрузка в два шага: спросить адрес для загрузки, потом отправить туда файл."""
        response = await self._request(
            'GET', '/resources/upload', params={'path': disk_path, 'overwrite': 'true'},
        )
        if response.status_code != 200:
            raise YandexDiskError(f'Нет ссылки для загрузки: {response.status_code} {response.text[:200]}')
        link = DiskLink.model_validate(response.json())

        content = await asyncio.to_thread(local_path.read_bytes)   # чтение файла не блокирует event loop
        # Ссылка ведёт на другой сервер (uploader) — полный URL; токен туда не отправляем
        upload = await self._request(link.method, link.href, auth=False, content=content)
        if upload.status_code not in (201, 202):
            raise YandexDiskError(f'Файл не загрузился: {upload.status_code}')

    async def publish(self, disk_path: str) -> str:
        """Открыть доступ по ссылке и вернуть публичный URL."""
        response = await self._request('PUT', '/resources/publish', params={'path': disk_path})
        if response.status_code != 200:
            raise YandexDiskError(f'Не удалось опубликовать: {response.status_code} {response.text[:200]}')
        meta = await self._request('GET', '/resources', params={'path': disk_path, 'fields': 'public_url'})
        if meta.status_code != 200:
            raise YandexDiskError(f'Нет публичной ссылки: {meta.status_code}')
        return meta.json()['public_url']
