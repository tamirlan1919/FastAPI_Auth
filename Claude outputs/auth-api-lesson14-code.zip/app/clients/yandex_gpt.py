import logging

import httpx

logger = logging.getLogger(__name__)


class YandexGPTError(Exception):
    pass


class YandexGPTClient:
    def __init__(
        self,
        api_key: str,
        folder_id: str,
        model: str = 'yandexgpt-lite',
        base_url: str = 'https://llm.api.cloud.yandex.net',
        timeout: float = 15.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ):
        self.model_uri = f'gpt://{folder_id}/{model}/latest'
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={'Authorization': f'Api-Key {api_key}'},   # ключ сервисного аккаунта
            timeout=timeout,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def complete(self, system: str, user: str, temperature: float = 0.1, max_tokens: int = 200) -> str:
        body = {
            'modelUri': self.model_uri,
            'completionOptions': {'stream': False, 'temperature': temperature, 'maxTokens': str(max_tokens)},
            'messages': [
                {'role': 'system', 'text': system},
                {'role': 'user', 'text': user},
            ],
        }
        try:
            response = await self._client.post('/foundationModels/v1/completion', json=body)
        except httpx.TimeoutException as exc:
            raise YandexGPTError('YandexGPT не ответил вовремя') from exc
        except httpx.TransportError as exc:
            raise YandexGPTError(f'YandexGPT недоступен: {exc!r}') from exc

        if response.status_code != 200:
            logger.warning('YandexGPT ответил %s: %s', response.status_code, response.text[:300])
            raise YandexGPTError(f'YandexGPT ответил {response.status_code}')

        result = response.json()['result']
        usage = result['usage']
        logger.info('YandexGPT: токенов на входе %s, на выходе %s',
                    usage['inputTextTokens'], usage['completionTokens'])
        return result['alternatives'][0]['message']['text']
