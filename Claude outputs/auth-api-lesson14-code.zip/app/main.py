from asyncio import ensure_future
import logging

import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from prometheus_fastapi_instrumentator import Instrumentator
from app.api.routers import users, auth, todos, stats, posts, reports, github, yandex_auth
from app.db.database import Base, engine
from app.db import models  # noqa: F401 — регистрирует модели в Base.metadata для create_all
from contextlib import asynccontextmanager
from app.db.redis_db import create_redis
from app.broker.rabbit import connect_rabbit, declare_events_exchange, EventPublisher
from app.clients.github import GitHubClient
from app.clients.yandex_disk import YandexDiskClient
from app.clients.yandex_gpt import YandexGPTClient
from app.clients.yandex_oauth import YandexOAuthClient
from app.core.config import settings



# Логи наших модулей (app.*) — в консоль uvicorn
app_logger = logging.getLogger('app')
app_logger.setLevel(logging.INFO)
_handler = logging.StreamHandler()
_handler.setFormatter(logging.Formatter('%(levelname)s %(name)s: %(message)s'))
app_logger.addHandler(_handler)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.redis = create_redis()
    await app.state.redis.ping()

    app.state.rabbit = await connect_rabbit('auth-api')
    channel = await app.state.rabbit.channel()
    exchange = await declare_events_exchange(channel)
    app.state.publisher = EventPublisher(exchange)

    token = settings.github_token.get_secret_value() if settings.github_token else None
    app.state.github = GitHubClient(
        base_url=settings.github_api_url,
        token=token,
        timeout=settings.github_timeout,
        retries=settings.github_retries,
    )

    app.state.yandex_oauth = app.state.yandex_disk = app.state.yandex_gpt = None
    if settings.yandex_client_id and settings.yandex_client_secret:
        app.state.yandex_oauth = YandexOAuthClient(
            client_id=settings.yandex_client_id,
            client_secret=settings.yandex_client_secret.get_secret_value(),
            redirect_uri=settings.yandex_redirect_uri,
            oauth_url=settings.yandex_oauth_url,
            login_url=settings.yandex_login_url,
        )
    if settings.yandex_disk_token:
        app.state.yandex_disk = YandexDiskClient(
            token=settings.yandex_disk_token.get_secret_value(),
            base_url=settings.yandex_disk_url,
        )
    if settings.yandex_gpt_api_key and settings.yandex_folder_id:
        app.state.yandex_gpt = YandexGPTClient(
            api_key=settings.yandex_gpt_api_key.get_secret_value(),
            folder_id=settings.yandex_folder_id,
            base_url=settings.yandex_gpt_url,
        )

    yield
    for client in (app.state.yandex_oauth, app.state.yandex_disk, app.state.yandex_gpt):
        if client is not None:
            await client.aclose()
    await app.state.github.aclose()
    await app.state.rabbit.close()
    await app.state.redis.aclose()



app = FastAPI(lifespan=lifespan)
app.include_router(users.router)
app.include_router(auth.router)
app.include_router(todos.router)
app.include_router(stats.router)
app.include_router(posts.router)
app.include_router(reports.router)
app.include_router(github.router)
app.include_router(yandex_auth.router)

# Prometheus: middleware считает запросы/латентность, GET /metrics отдаёт их в формате Prometheus
Instrumentator(
    should_group_status_codes=False,         # status="404", а не "4xx"
    should_ignore_untemplated=True,          # не плодим метрики на несуществующие пути (сканеры, опечатки)
    should_instrument_requests_inprogress=True,
    inprogress_labels=True,
    excluded_handlers=["/metrics"],
).instrument(app).expose(app, include_in_schema=False)


@app.get("/")
async def root():
    return {"message": "Hello World"}


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)



if __name__ == '__main__':
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)