from celery.result import AsyncResult
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse

from app.api.deps import CurrentUserDep, YandexDiskDep
from app.clients.yandex_disk import YandexDiskError
from app.shemas.yandex import DiskUploadOut
from app.tasks.celery_app import celery_app
from app.tasks.reports import REPORTS_DIR, generate_users_report

router = APIRouter(prefix="/reports", tags=["reports"])

@router.post('/users', status_code=status.HTTP_202_ACCEPTED)
def create_users_report():
    task = generate_users_report.delay()
    return {'task_id': task.id, 'status_url': f'/reports/tasks/{task.id}'}


@router.get('/tasks/{task_id}', status_code=status.HTTP_200_OK)
def get_task_status(task_id: str):
    result = AsyncResult(task_id, app=celery_app)
    response = {'task_id': result.task_id, 'status': result.status}
    if result.status == 'PROGRESS':
        response['progress'] = result.info
    elif result.successful():
        response['result'] = result.result
    elif result.failed():
        response['error'] = str(result.result)

    return response

DISK_FOLDER = 'app:/reports'   # app:/ — папка приложения: «Диск/Приложения/<имя приложения>»


@router.post('/{file_name}/yandex-disk', response_model=DiskUploadOut)
async def upload_report_to_disk(file_name: str, disk: YandexDiskDep, current_user: CurrentUserDep):
    path = (REPORTS_DIR / file_name).resolve()
    # защита от path traversal: только файлы прямо внутри папки reports
    if path.parent != REPORTS_DIR.resolve() or not path.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, 'Отчёт не найден')

    disk_path = f'{DISK_FOLDER}/{file_name}'
    try:
        await disk.ensure_folder(DISK_FOLDER)
        await disk.upload(path, disk_path)
        public_url = await disk.publish(disk_path)
    except YandexDiskError:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, 'Не удалось загрузить отчёт на Яндекс Диск')

    return DiskUploadOut(path=disk_path, public_url=public_url)
