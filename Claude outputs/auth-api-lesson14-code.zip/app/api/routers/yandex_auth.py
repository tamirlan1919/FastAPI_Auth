import secrets

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import RedirectResponse

from app.api.deps import RedisDep, UserRepoDep, YandexOAuthDep
from app.clients.yandex_oauth import YandexOAuthError
from app.core.security import create_access_token
from app.services.yandex_auth_service import YandexEmailRequired, login_or_register
from app.shemas.token import Token

router = APIRouter(prefix='/auth/yandex', tags=['Вход через Яндекс'])

STATE_TTL = 600  # 10 минут на то, чтобы нажать «Разрешить»


@router.get('/login')
async def yandex_login(yandex: YandexOAuthDep, redis: RedisDep):
    state = secrets.token_urlsafe(16)                        # одноразовая метка против CSRF
    await redis.set(f'oauth:state:{state}', '1', ex=STATE_TTL)
    return RedirectResponse(yandex.authorize_url(state))     # 307 → oauth.yandex.ru


@router.get('/callback', response_model=Token)
async def yandex_callback(
    user_repo: UserRepoDep,
    yandex: YandexOAuthDep,
    redis: RedisDep,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
):
    if error:                                                # пользователь нажал «Отмена»
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f'Яндекс: {error_description or error}')

    if not code or not state or not await redis.getdel(f'oauth:state:{state}'):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, 'Неверный или устаревший state, начните вход заново')

    try:
        token = await yandex.exchange_code(code)
        profile = await yandex.get_profile(token.access_token)
    except YandexOAuthError:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, 'Не удалось войти через Яндекс')

    try:
        user = await login_or_register(user_repo, profile)
    except YandexEmailRequired:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, 'Разрешите приложению доступ к email на странице Яндекса')

    return Token(access_token=create_access_token(data={'sub': user.username}))
