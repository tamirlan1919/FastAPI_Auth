from pydantic import BaseModel


# --- Яндекс ID ---

class YandexToken(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    refresh_token: str | None = None


class YandexProfile(BaseModel):
    """Ответ https://login.yandex.ru/info — только нужные нам поля."""
    id: str
    login: str
    display_name: str | None = None
    real_name: str | None = None
    default_email: str | None = None        # придёт, только если у приложения есть право login:email
    default_avatar_id: str | None = None
    is_avatar_empty: bool = True

    @property
    def avatar_url(self) -> str | None:
        if self.is_avatar_empty or not self.default_avatar_id:
            return None
        return f'https://avatars.yandex.net/get-yapic/{self.default_avatar_id}/islands-200'


# --- Яндекс Диск ---

class DiskLink(BaseModel):
    """Типичный ответ Диска: «вот ссылка, куда идти дальше»."""
    href: str
    method: str
    templated: bool = False


class DiskUploadOut(BaseModel):
    path: str
    public_url: str


# --- YandexGPT ---

class SuggestTagsIn(BaseModel):
    title: str


class SuggestTagsOut(BaseModel):
    tags: list[str]
    source: str          # 'yandexgpt' или 'fallback'
