import asyncio
import time


def sync_sdk_call(n: int) -> int:
    """Так ведёт себя любой синхронный SDK: ждёт ответа сети и держит поток."""
    time.sleep(1)
    return n


async def heartbeat(stop: asyncio.Event) -> int:
    """Пока event loop свободен, «сердце» бьётся 10 раз в секунду."""
    beats = 0
    while not stop.is_set():
        await asyncio.sleep(0.1)
        beats += 1
    return beats


async def run(title: str, call):
    stop = asyncio.Event()
    hb = asyncio.create_task(heartbeat(stop))
    start = time.perf_counter()
    await asyncio.gather(*(call(i) for i in range(5)))
    elapsed = time.perf_counter() - start
    stop.set()
    print(f'{title:28} 5 вызовов: {elapsed:.2f} с, ударов сердца: {await hb}')


async def blocking(n):            # синхронный вызов прямо в корутине
    return sync_sdk_call(n)


async def in_thread(n):           # тот же вызов в отдельном потоке
    return await asyncio.to_thread(sync_sdk_call, n)


async def main():
    await run('прямо в async def', blocking)
    await run('через asyncio.to_thread', in_thread)


if __name__ == '__main__':
    asyncio.run(main())
