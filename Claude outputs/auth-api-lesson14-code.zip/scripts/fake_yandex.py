"""Имитация API Яндекса по официальной документации — только для проверки урока."""
import base64, json, re, secrets, time
from urllib.parse import urlencode, quote
from fastapi import FastAPI, Request, Form, Header
from fastapi.responses import JSONResponse, RedirectResponse, Response

app = FastAPI()
BASE = 'http://127.0.0.1:9200'
CLIENT_ID, CLIENT_SECRET = 'a1b2c3d4e5f6', 's3cr3t-from-oauth-yandex'
CODES, TOKENS = {}, {}
DISK, UPLOADS = {}, {}
GPT_KEY = 'AQVN-test-api-key'
PROFILE = {"id": "1130000071234567", "login": "anna.frontend", "client_id": CLIENT_ID,
           "display_name": "Анна", "real_name": "Анна Смирнова", "first_name": "Анна", "last_name": "Смирнова",
           "sex": "female", "default_email": "anna.frontend@yandex.ru", "emails": ["anna.frontend@yandex.ru"],
           "default_avatar_id": "1450263/AbCdEfGh-1", "is_avatar_empty": False, "psuid": "1.AAbbCC.xyz"}

@app.get('/authorize')
def authorize(response_type: str, client_id: str, redirect_uri: str, state: str = ''):
    if client_id != CLIENT_ID:
        return JSONResponse({"error": "invalid_client"}, 400)
    code = str(secrets.randbelow(9_000_000) + 1_000_000)      # Яндекс выдаёт 7-значный код
    CODES[code] = time.time()
    # пользователь «нажал Разрешить» — Яндекс возвращает браузер на redirect_uri
    return RedirectResponse(f'{redirect_uri}?{urlencode({"code": code, "state": state})}', 302)

@app.post('/token')
async def token(request: Request):
    form = await request.form()
    cid, csec = form.get('client_id'), form.get('client_secret')
    if not cid and request.headers.get('authorization', '').startswith('Basic '):
        cid, csec = base64.b64decode(request.headers['authorization'][6:]).decode().split(':', 1)
    if form.get('grant_type') != 'authorization_code':
        return JSONResponse({"error": "unsupported_grant_type", "error_description": "Unsupported grant type"}, 400)
    if cid != CLIENT_ID or csec != CLIENT_SECRET:
        return JSONResponse({"error": "invalid_client", "error_description": "Client not found"}, 400)
    if CODES.pop(form.get('code'), None) is None:
        return JSONResponse({"error": "invalid_grant", "error_description": "Code has expired"}, 400)
    tok = 'y0_' + secrets.token_urlsafe(40)
    TOKENS[tok] = PROFILE
    return {"access_token": tok, "expires_in": 31536000, "refresh_token": '1:' + secrets.token_urlsafe(30), "token_type": "bearer"}

@app.get('/info')
def info(format: str = 'json', authorization: str = Header('')):
    tok = authorization.removeprefix('OAuth ').strip()
    if tok not in TOKENS:
        return Response('invalid token', 401)
    return TOKENS[tok]

# ---------- Диск ----------
DISK_TOKEN = 'y0_disk-owner-token'
def disk_auth(a): return a == f'OAuth {DISK_TOKEN}'
def err(status, error, desc, msg):
    return JSONResponse({"message": msg, "description": desc, "error": error}, status)
def parent(p): return p.rsplit('/', 1)[0] if p.count('/') > 1 else 'app:'

@app.put('/v1/disk/resources')
def mkdir(path: str, authorization: str = Header('')):
    if not disk_auth(authorization): return err(401, 'UnauthorizedError', 'Unauthorized', 'Не авторизован.')
    if path in DISK: return err(409, 'DiskPathPointsToExistentDirectoryError', f'Specified path "{path}" points to existent directory.', f'По указанному пути "{path}" уже существует папка с таким именем.')
    DISK[path] = {'type': 'dir'}
    return JSONResponse({"href": f"https://cloud-api.yandex.net/v1/disk/resources?path={quote(path, safe='')}", "method": "GET", "templated": False}, 201)

@app.get('/v1/disk/resources/upload')
def upload_link(path: str, overwrite: str = 'false', authorization: str = Header('')):
    if not disk_auth(authorization): return err(401, 'UnauthorizedError', 'Unauthorized', 'Не авторизован.')
    if parent(path) not in DISK and parent(path) != 'app:':
        return err(409, 'DiskPathDoesntExistsError', f'Specified path "{path}" doesn\'t exists.', 'Указанного пути не существует.')
    if path in DISK and overwrite != 'true':
        return err(409, 'DiskResourceAlreadyExistsError', f'Resource "{path}" already exists.', f'Ресурс "{path}" уже существует.')
    op = secrets.token_hex(16); UPLOADS[op] = path
    return {"operation_id": op, "href": f"{BASE}/upload-target/{op}", "method": "PUT", "templated": False}

@app.put('/upload-target/{op}')
async def upload_put(op: str, request: Request):
    path = UPLOADS.pop(op, None)
    if path is None: return Response(status_code=404)
    old = DISK.get(path, {})
    DISK[path] = {'type': 'file', 'size': len(await request.body()), **({'public_url': old['public_url']} if 'public_url' in old else {})}
    return Response(status_code=201)

@app.put('/v1/disk/resources/publish')
def publish(path: str, authorization: str = Header('')):
    if not disk_auth(authorization): return err(401, 'UnauthorizedError', 'Unauthorized', 'Не авторизован.')
    if path not in DISK: return err(404, 'DiskNotFoundError', 'Resource not found.', 'Не удалось найти запрошенный ресурс.')
    DISK[path].setdefault('public_url', 'https://disk.yandex.ru/d/' + secrets.token_urlsafe(10)[:14])
    return {"href": f"https://cloud-api.yandex.net/v1/disk/resources?path={quote(path, safe='')}", "method": "GET", "templated": False}

@app.get('/v1/disk/resources')
def meta(path: str, fields: str = '', authorization: str = Header('')):
    if not disk_auth(authorization): return err(401, 'UnauthorizedError', 'Unauthorized', 'Не авторизован.')
    if path not in DISK: return err(404, 'DiskNotFoundError', 'Resource not found.', 'Не удалось найти запрошенный ресурс.')
    return {"public_url": DISK[path].get('public_url')}

# ---------- YandexGPT ----------
KEYWORDS = ['fastapi', 'redis', 'celery', 'docker', 'postgresql', 'python', 'sql', 'rabbitmq', 'react', 'typescript', 'vite']
@app.post('/foundationModels/v1/completion')
async def completion(request: Request, authorization: str = Header('')):
    if authorization != f'Api-Key {GPT_KEY}':
        return JSONResponse({"error": {"grpcCode": 16, "httpCode": 401, "message": "Unknown api key 'AQVN****'", "httpStatus": "Unauthorized", "details": []}}, 401)
    body = await request.json()
    user = body['messages'][-1]['text']
    found = [k for k in KEYWORDS if k in user.lower().replace('postgres ', 'postgresql ')]
    tags = (found or ['backend'])[:4] + (['performance'] if re.search('ускор|быстр', user.lower()) else [])
    text = '```json\n' + json.dumps(tags, ensure_ascii=False) + '\n```'
    n_in = len(body['messages'][0]['text'].split()) * 2 + len(user.split()) * 2
    return {"result": {"alternatives": [{"message": {"role": "assistant", "text": text}, "status": "ALTERNATIVE_STATUS_FINAL"}],
            "usage": {"inputTextTokens": str(n_in), "completionTokens": str(len(tags) * 3 + 6), "totalTokens": str(n_in + len(tags) * 3 + 6)},
            "modelVersion": "imitation"}}
