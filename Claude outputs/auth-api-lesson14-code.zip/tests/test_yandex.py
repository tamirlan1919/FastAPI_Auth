import json
from urllib.parse import parse_qs, urlparse

import httpx
import pytest

from app.clients.yandex_disk import YandexDiskClient, YandexDiskError
from app.clients.yandex_gpt import YandexGPTClient
from app.clients.yandex_oauth import YandexOAuthClient, YandexOAuthError
from app.services.tag_suggester import parse_tags


def oauth_client(handler) -> YandexOAuthClient:
    return YandexOAuthClient('cid', 'secret', 'http://localhost:8000/cb',
                             transport=httpx.MockTransport(handler))


def test_authorize_url():
    url = urlparse(oauth_client(lambda r: None).authorize_url('xyz'))
    params = parse_qs(url.query)
    assert url.netloc == 'oauth.yandex.ru'
    assert params['response_type'] == ['code']
    assert params['state'] == ['xyz']


async def test_exchange_code_and_profile():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == '/token':
            form = parse_qs(request.content.decode())
            assert form['grant_type'] == ['authorization_code']
            assert form['code'] == ['1234567']
            return httpx.Response(200, json={'access_token': 'y0_abc', 'expires_in': 31536000,
                                             'token_type': 'bearer'})
        assert request.headers['Authorization'] == 'OAuth y0_abc'      # не Bearer!
        return httpx.Response(200, json={'id': '42', 'login': 'anna', 'default_email': 'a@yandex.ru'})

    client = oauth_client(handler)
    token = await client.exchange_code('1234567')
    profile = await client.get_profile(token.access_token)
    assert profile.login == 'anna'
    assert profile.avatar_url is None


async def test_expired_code():
    client = oauth_client(lambda r: httpx.Response(
        400, json={'error': 'invalid_grant', 'error_description': 'Code has expired'}))
    with pytest.raises(YandexOAuthError, match='Code has expired'):
        await client.exchange_code('1234567')


async def test_disk_upload_flow(tmp_path):
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append((request.method, request.url.path, request.headers.get('Authorization')))
        if request.url.path == '/v1/disk/resources' and request.method == 'PUT':
            return httpx.Response(409, json={'error': 'DiskPathPointsToExistentDirectoryError'})
        if request.url.path == '/v1/disk/resources/upload':
            return httpx.Response(200, json={'href': 'https://uploader1.disk.yandex.net/upload/1',
                                             'method': 'PUT', 'templated': False})
        if request.url.host.startswith('uploader'):
            assert request.content == b'id,name\n'
            return httpx.Response(201)
        if request.url.path == '/v1/disk/resources/publish':
            return httpx.Response(200, json={'href': '...', 'method': 'GET'})
        return httpx.Response(200, json={'public_url': 'https://disk.yandex.ru/d/abc'})

    report = tmp_path / 'r.csv'
    report.write_text('id,name\n')
    disk = YandexDiskClient('tok', transport=httpx.MockTransport(handler))
    await disk.ensure_folder('app:/reports')                 # 409 — не ошибка
    await disk.upload(report, 'app:/reports/r.csv')
    assert await disk.publish('app:/reports/r.csv') == 'https://disk.yandex.ru/d/abc'
    uploader_call = calls[2]
    assert uploader_call[2] is None                          # токен на uploader не ушёл


async def test_disk_error():
    disk = YandexDiskClient('tok', transport=httpx.MockTransport(
        lambda r: httpx.Response(401, json={'error': 'UnauthorizedError'})))
    with pytest.raises(YandexDiskError):
        await disk.ensure_folder('app:/reports')


async def test_gpt_request_format():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers['Authorization'] == 'Api-Key key'
        body = json.loads(request.content)
        assert body['modelUri'] == 'gpt://folder1/yandexgpt-lite/latest'
        assert body['messages'][0]['role'] == 'system'
        return httpx.Response(200, json={'result': {
            'alternatives': [{'message': {'role': 'assistant', 'text': '["python"]'}}],
            'usage': {'inputTextTokens': '10', 'completionTokens': '3', 'totalTokens': '13'}}})

    gpt = YandexGPTClient('key', 'folder1', transport=httpx.MockTransport(handler))
    assert await gpt.complete('sys', 'user') == '["python"]'


@pytest.mark.parametrize('text, expected', [
    ('["python", "fastapi"]', ['python', 'fastapi']),
    ('```json\n["Docker", "#SQL"]\n```', ['docker', 'sql']),
    ('Конечно! Вот теги: ["redis", "redis", "cache"]', ['redis', 'cache']),
    ('["a", "b", "c", "d", "e", "f", "g"]', ['a', 'b', 'c', 'd', 'e']),
])
def test_parse_tags(text, expected):
    assert parse_tags(text) == expected


@pytest.mark.parametrize('text', ['Теги: python, fastapi', '[1, 2, 3]', '["python", '])
def test_parse_tags_garbage(text):
    with pytest.raises(ValueError):
        parse_tags(text)
