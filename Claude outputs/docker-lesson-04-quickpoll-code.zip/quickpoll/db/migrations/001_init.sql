-- Миграция 001: таблицы опроса. Можно запускать сколько угодно раз (IF NOT EXISTS / ON CONFLICT).
CREATE TABLE IF NOT EXISTS options (
    id    SERIAL PRIMARY KEY,
    name  TEXT NOT NULL UNIQUE,
    emoji TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS votes (
    id         BIGSERIAL PRIMARY KEY,
    option_id  INT NOT NULL REFERENCES options (id),
    voter_ip   TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO options (name, emoji) VALUES
    ('React', '⚛️'), ('Vue', '🟢'), ('Svelte', '🔥'), ('Angular', '🅰️')
ON CONFLICT (name) DO NOTHING;
