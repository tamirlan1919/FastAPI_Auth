const http = require('node:http');
const os = require('node:os');
const { Pool } = require('pg');
const { createClient } = require('redis');

// Всё подключение — из переменных окружения (их задаёт compose.yaml)
const db = new Pool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'quickpoll',
});
db.on('error', (err) => console.error('Соединение с БД потеряно:', err.message));

const redis = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
redis.on('error', (err) => console.error('Redis:', err.message));

const VOTE_COOLDOWN = 10;          // секунд между голосами с одного IP
const RESULTS_TTL = 5;             // секунд живёт кеш результатов
const SERVED_BY = os.hostname();   // в контейнере это его короткий id

// --- ограничение «один голос в 10 секунд» ---
// Учебный переключатель: RATE_LIMIT_STORE=memory хранит отметки в памяти процесса (блок 07)
const memory = new Map();
async function tryVoteSlot(ip) {
  if (process.env.RATE_LIMIT_STORE === 'memory') {
    const until = memory.get(ip) || 0;
    if (until > Date.now()) return false;
    memory.set(ip, Date.now() + VOTE_COOLDOWN * 1000);
    return true;
  }
  // SET … NX EX: записать, только если ключа ещё нет, и удалить через 10 с — атомарно
  return (await redis.set(`vote:ip:${ip}`, '1', { NX: true, EX: VOTE_COOLDOWN })) === 'OK';
}

async function getResults() {
  const cached = await redis.get('results');
  if (cached) return { ...JSON.parse(cached), cached: true };
  const { rows } = await db.query(`
    SELECT o.id, o.name, o.emoji, count(v.id)::int AS votes
    FROM options o LEFT JOIN votes v ON v.option_id = o.id
    GROUP BY o.id ORDER BY o.id`);
  const data = { total: rows.reduce((s, r) => s + r.votes, 0), items: rows };
  await redis.set('results', JSON.stringify(data), { EX: RESULTS_TTL });
  return { ...data, cached: false };
}

function clientIp(req) {
  // за nginx настоящий адрес клиента — в X-Forwarded-For
  return (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch (e) { reject(e); } });
  });
}

function send(res, status, data) {
  console.log(`${res.req.method} ${res.req.url} → ${status}`);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'X-Served-By': SERVED_BY });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  const { pathname } = new URL(req.url, 'http://localhost');
  try {
    if (req.method === 'GET' && pathname === '/results') {
      return send(res, 200, { ...(await getResults()), served_by: SERVED_BY });
    }
    if (req.method === 'POST' && pathname === '/vote') {
      const { option_id } = await readJson(req);
      const ip = clientIp(req);
      if (!(await tryVoteSlot(ip))) {
        return send(res, 429, { error: `Голосовать можно раз в ${VOTE_COOLDOWN} секунд` });
      }
      await db.query('INSERT INTO votes (option_id, voter_ip) VALUES ($1, $2)', [option_id, ip]);
      await redis.del('results');                 // кеш устарел
      return send(res, 201, { ok: true, served_by: SERVED_BY });
    }
    if (pathname === '/health') {
      await db.query('SELECT 1');
      await redis.ping();
      return send(res, 200, { status: 'ok' });
    }
    send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('Ошибка:', err.message);
    send(res, 500, { error: err.message });
  }
});

redis.connect().then(() => {
  server.listen(3000, () => console.log(`quickpoll-api (${SERVED_BY}) слушает порт 3000`));
});

function shutdown(signal) {
  console.log(`Получен ${signal}: закрываюсь`);
  server.close(async () => {
    await Promise.allSettled([db.end(), redis.quit()]);
    process.exit(0);
  });
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
