import { defineConfig } from 'vite'

// В разработке /api проксирует Vite (как nginx в проде).
// В контейнере API доступен по имени сервиса, на хосте — на localhost.
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: process.env.API_PROXY_TARGET ?? 'http://localhost:3000',
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
