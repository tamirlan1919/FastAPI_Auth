import './style.css'

type Item = { id: number; name: string; emoji: string; votes: number }
type Results = { total: number; items: Item[]; cached: boolean; served_by: string }

// Адрес API «запекается» при сборке (урок 3). /api — тот же адрес, что и у страницы
const API_URL = import.meta.env.VITE_API_URL ?? '/api'

const app = document.querySelector<HTMLDivElement>('#app')!
app.innerHTML = `
  <h1>🗳️ QuickPoll</h1>
  <p class="question">Какой фреймворк вы бы взяли в новый проект?</p>
  <ul id="options"><li>Загрузка…</li></ul>
  <p id="status" class="status"></p>
  <p class="meta">API: <code>${API_URL}</code> · ответил контейнер <code id="served">—</code> · <span id="cache"></span></p>
`
const list = document.querySelector<HTMLUListElement>('#options')!
const status = document.querySelector<HTMLParagraphElement>('#status')!

function render(r: Results) {
  list.innerHTML = r.items
    .map((it) => {
      const pct = r.total ? Math.round((it.votes / r.total) * 100) : 0
      return `<li>
        <button data-id="${it.id}">${it.emoji} ${it.name}</button>
        <div class="bar"><span style="width:${pct}%"></span></div>
        <b>${it.votes}</b>
      </li>`
    })
    .join('')
  document.querySelector('#served')!.textContent = r.served_by
  document.querySelector('#cache')!.textContent = r.cached ? 'из кеша Redis' : 'из Postgres'
}

async function load() {
  try {
    const r = await fetch(`${API_URL}/results`)
    render(await r.json())
  } catch {
    list.innerHTML = '<li class="error">API недоступен</li>'
  }
}

list.addEventListener('click', async (e) => {
  const btn = (e.target as HTMLElement).closest('button')
  if (!btn) return
  const r = await fetch(`${API_URL}/vote`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ option_id: Number(btn.dataset.id) }),
  })
  const data = await r.json()
  status.textContent = r.ok ? '✅ Голос принят!' : `⏳ ${data.error}`
  status.className = r.ok ? 'status ok' : 'status wait'
  load()
})

load()
setInterval(load, 3000) // «живые» результаты
