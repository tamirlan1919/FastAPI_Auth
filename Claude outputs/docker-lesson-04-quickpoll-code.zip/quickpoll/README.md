# QuickPoll — учебный проект к уроку «Docker Compose»

Опрос «Какой фреймворк взять в новый проект?»: фронтенд (Vite → nginx), API (Node.js),
PostgreSQL, Redis, миграции отдельным сервисом и Adminer для просмотра базы.

    cp .env.example .env                       # и поменяйте пароль
    docker compose up -d --build               # режим разработки: http://localhost:5173
    docker compose -f compose.yaml up -d       # «как в проде»:     http://localhost:8080
    docker compose --profile tools up -d       # + Adminer:          http://localhost:8081
    docker compose down                        # остановить (данные остаются)
    docker compose down -v                     # остановить и удалить данные
