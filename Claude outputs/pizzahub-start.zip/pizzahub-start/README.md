# PizzaHub — стартовый проект

Нужен Node.js 20+.

    npm install
    npm run dev        # должно напечатать: 🍕 PizzaHub запущен
    npm run typecheck  # проверка типов

Паттерны будем добавлять на уроке, по одному файлу на паттерн.
