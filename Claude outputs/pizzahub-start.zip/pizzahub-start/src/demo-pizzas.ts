// Временные данные, пока у нас нет «бэкенда». На шаге Adapter заменим на настоящую загрузку.
import type { Pizza } from './types';

export const DEMO_PIZZAS: Pizza[] = [
  { id: 1, name: 'Маргарита', price: 499, isVegan: true, createdAt: new Date() },
  { id: 2, name: 'Пепперони', price: 599, isVegan: false, createdAt: new Date() },
];
