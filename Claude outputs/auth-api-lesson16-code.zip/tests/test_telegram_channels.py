"""Telethon-часть без сети: настоящие объекты Telethon + имитация клиента + Redis (db 15)."""
from datetime import datetime, timezone

import pytest
from redis.asyncio import Redis
from telethon.errors import FloodWaitError
from telethon.tl.types import Message, PeerChannel

from app.clients.telegram_channels import ChannelNotFound, message_to_post
from app.schemas.telegram import ChannelPost
from app.services.channel_import import import_posts, imported_key, post_tags, post_title
from scripts.fake_channels import FakeTelegramChannels


def msg(msg_id: int, text: str) -> Message:
    return Message(id=msg_id, peer_id=PeerChannel(1), date=datetime(2026, 11, 20, tzinfo=timezone.utc),
                   message=text, views=10)


def test_message_to_post():
    post = message_to_post(msg(7, '  Привет #fastapi  '), 'news')
    assert post.text == 'Привет #fastapi'
    assert post.url == 'https://t.me/news/7'


def test_photo_without_caption_is_skipped():
    assert message_to_post(msg(8, ''), 'news') is None


@pytest.mark.parametrize('text, title, tags', [
    ('Релиз 1.0\nподробности #python #Python', 'Релиз 1.0', ['python']),
    ('#новости\nЗаголовок со второй строки', 'Заголовок со второй строки', ['новости']),
    ('x' * 300, 'x' * 199 + '…', []),
], ids=['hashtags-at-end', 'hashtag-first-line', 'too-long'])
def test_title_and_tags(text, title, tags):
    assert post_title(text) == title
    assert post_tags(text) == tags


class FakePostRepo:
    def __init__(self):
        self.created = []

    async def create(self, title, author_id, tag_names=None):
        self.created.append((title, author_id, tag_names))
        return title


@pytest.fixture
async def redis():
    client = Redis.from_url('redis://localhost:6379/15', decode_responses=True)
    await client.delete(imported_key(1))
    yield client
    await client.delete(imported_key(1))
    await client.aclose()


async def test_import_is_idempotent(redis):
    posts = [ChannelPost(channel='news', message_id=i, date=datetime.now(timezone.utc), text=f'Пост {i}')
             for i in (3, 1, 2)]
    repo = FakePostRepo()
    first = await import_posts(repo, redis, 1, posts)
    second = await import_posts(repo, redis, 1, posts)
    assert first == ['Пост 1', 'Пост 2', 'Пост 3']   # старые первыми
    assert second == []


async def test_failed_create_does_not_mark_as_imported(redis):
    class BrokenRepo:
        async def create(self, *args):
            raise RuntimeError('БД упала')

    post = ChannelPost(channel='news', message_id=1, date=datetime.now(timezone.utc), text='Пост')
    with pytest.raises(RuntimeError):
        await import_posts(BrokenRepo(), redis, 1, [post])
    assert not await redis.sismember(imported_key(1), 'news:1')


async def test_fake_client_errors():
    tg = FakeTelegramChannels()
    with pytest.raises(ChannelNotFound):
        await tg.latest_posts('durov', 10)
    with pytest.raises(FloodWaitError) as e:
        await tg.latest_posts('flood_test', 10)
    assert e.value.seconds == 37
