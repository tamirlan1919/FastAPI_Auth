"""Написать боту от имени «пользователя» имитатора и показать ответ.

    python -m scripts.tg_user 111 "/start"
    python -m scripts.tg_user 111 "/me"
"""
import sys
import time

import httpx

FAKE = 'http://127.0.0.1:8081'


def main() -> None:
    user_id, text = int(sys.argv[1]), sys.argv[2]
    with httpx.Client(base_url=FAKE, timeout=15) as client:
        seen = len(client.get(f'/_chat/{user_id}').json())
        result = client.post('/_simulate/message', json={'user_id': user_id, 'text': text,
                                                         'first_name': 'Тима', 'username': 'tima'}).json()
        print(f'👤 {user_id}: {text}')
        if result.get('status') and result['status'] >= 300:
            print(f'   (вебхук ответил {result["status"]})')
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            new = [m for m in client.get(f'/_chat/{user_id}', params={'after': seen}).json() if m['who'] == 'bot']
            if new:
                time.sleep(0.3)
                new = [m for m in client.get(f'/_chat/{user_id}', params={'after': seen}).json() if m['who'] == 'bot']
                for m in new:
                    print('🤖 ' + m['text'].replace('\n', '\n   '))
                return
            time.sleep(0.1)
        print('🤖 (бот ничего не ответил за 3 секунды)')


if __name__ == '__main__':
    main()
