"""Один раз войти в Telegram-аккаунт и получить строку сессии для .env.

    python -m scripts.telethon_login

Спросит телефон, код из Telegram и пароль 2FA (если включён).
Строка — это полный доступ к аккаунту: только в .env, никогда в git и в чаты.
"""
from telethon.sessions import StringSession
from telethon.sync import TelegramClient

from app.core.config import settings


def main() -> None:
    if not settings.telethon_api_id or not settings.telethon_api_hash:
        raise SystemExit('Сначала TELETHON_API_ID и TELETHON_API_HASH в .env (my.telegram.org → API development tools)')
    with TelegramClient(StringSession(), settings.telethon_api_id,
                        settings.telethon_api_hash.get_secret_value()) as client:
        me = client.get_me()
        print(f'Вошли как {me.first_name} (id={me.id})')
        print('\nДобавьте в .env:\nTELETHON_SESSION=' + client.session.save())


if __name__ == '__main__':
    main()
