"""Учебный имитатор Telegram Bot API — для занятий и тестов, когда настоящий Telegram недоступен.

Это НЕ Telegram. Он умеет ровно столько, сколько нужно уроку:
getMe, setMyCommands, setWebhook, deleteWebhook, getWebhookInfo, getUpdates, sendMessage
+ «пользователей», которые пишут боту (POST /_simulate/message).
Тексты ошибок взяты такими, какими их возвращает настоящий Bot API.

Запуск:  uvicorn scripts.fake_telegram:app --port 8081
В .env:  TELEGRAM_API_URL=http://127.0.0.1:8081
"""
import asyncio
import itertools
import json
import os
import time
from html import escape
from html.parser import HTMLParser

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

TOKEN = os.getenv('FAKE_TG_TOKEN', '7000000001:AAFakeTokenForLesson15_xxxxxxxxxxxx')
BOT = {
    'id': int(TOKEN.split(':')[0]), 'is_bot': True, 'first_name': 'auth-api bot',
    'username': 'authapi_lesson_bot', 'can_join_groups': True,
    'can_read_all_group_messages': False, 'supports_inline_queries': False,
}
ALLOWED_TAGS = {'b', 'strong', 'i', 'em', 'u', 'ins', 's', 'strike', 'del', 'a', 'code', 'pre',
                'tg-spoiler', 'span', 'blockquote', 'tg-emoji'}

app = FastAPI(title='Fake Telegram Bot API')
state = {'webhook_url': '', 'secret': None, 'allowed_updates': None, 'commands': [],
         'pending': [], 'last_error': None, 'blocked': set(), 'started': set()}
chats: dict[int, list[dict]] = {}
update_ids = itertools.count(100_000_001)
message_ids = itertools.count(1)
new_update = asyncio.Event()
poll_generation = itertools.count()
active_poll = {'gen': None}


def ok(result):
    return JSONResponse({'ok': True, 'result': result})


def fail(code: int, description: str):
    return JSONResponse({'ok': False, 'error_code': code, 'description': description}, status_code=code)


def log(text: str):
    print(f'[fake-tg {time.strftime("%H:%M:%S")}] {text}', flush=True)


class _TagCheck(HTMLParser):
    def __init__(self):
        super().__init__()
        self.bad = None

    def handle_starttag(self, tag, attrs):
        if tag not in ALLOWED_TAGS and self.bad is None:
            self.bad = tag


def check_html(text: str) -> str | None:
    parser = _TagCheck()
    parser.feed(text)
    if parser.bad is None:
        return None
    offset = len(text[: text.find(f'<{parser.bad}')].encode('utf-8'))
    return f'Bad Request: can\'t parse entities: Unsupported start tag "{parser.bad}" at byte offset {offset}'


async def params(request: Request) -> dict:
    if request.method == 'GET':
        return dict(request.query_params)
    ctype = request.headers.get('content-type', '')
    if 'application/json' in ctype:
        return await request.json()
    form = await request.form()
    out = {}
    for key, value in form.items():
        try:
            out[key] = json.loads(value)
        except (TypeError, json.JSONDecodeError):
            out[key] = value
    return out


@app.api_route('/bot{token}/{method}', methods=['GET', 'POST'])
async def bot_api(token: str, method: str, request: Request):
    if token != TOKEN:
        return fail(401, 'Unauthorized')
    p = await params(request)
    m = method.lower()

    if m == 'getme':
        return ok(BOT)
    if m == 'setmycommands':
        state['commands'] = p.get('commands', [])
        return ok(True)
    if m == 'setwebhook':
        state.update(webhook_url=p.get('url', ''), secret=p.get('secret_token'),
                     allowed_updates=p.get('allowed_updates'))
        log(f'setWebhook url={state["webhook_url"]} allowed_updates={state["allowed_updates"]}')
        return ok(True)
    if m == 'deletewebhook':
        state['webhook_url'] = ''
        if str(p.get('drop_pending_updates', '')).lower() in ('true', '1'):
            state['pending'].clear()
        log('deleteWebhook')
        return ok(True)
    if m == 'getwebhookinfo':
        info = {'url': state['webhook_url'], 'has_custom_certificate': False,
                'pending_update_count': len(state['pending'])}
        if state['last_error']:
            info.update(last_error_date=state['last_error'][0], last_error_message=state['last_error'][1])
        if state['allowed_updates']:
            info['allowed_updates'] = state['allowed_updates']
        return ok(info)
    if m == 'getupdates':
        return await get_updates(p)
    if m == 'sendmessage':
        return send_message(p)
    return fail(404, 'Not Found')


async def get_updates(p: dict):
    if state['webhook_url']:
        return fail(409, "Conflict: can't use getUpdates method while webhook is active; "
                         "use deleteWebhook to delete the webhook first")
    gen = next(poll_generation)
    active_poll['gen'] = gen
    new_update.set()  # будим предыдущий getUpdates — он получит 409
    await asyncio.sleep(0)
    offset = int(p.get('offset') or 0)
    if offset:
        state['pending'] = [u for u in state['pending'] if u['update_id'] >= offset]
    timeout = float(p.get('timeout') or 0)
    deadline = time.monotonic() + timeout
    while not state['pending'] and time.monotonic() < deadline:
        new_update.clear()
        try:
            await asyncio.wait_for(new_update.wait(), timeout=max(0.0, deadline - time.monotonic()))
        except asyncio.TimeoutError:
            break
        if active_poll['gen'] != gen:
            return fail(409, 'Conflict: terminated by other getUpdates request; '
                             'make sure that only one bot instance is running')
    if active_poll['gen'] != gen:
        return fail(409, 'Conflict: terminated by other getUpdates request; '
                         'make sure that only one bot instance is running')
    return ok(state['pending'][:100])


def send_message(p: dict):
    chat_id = int(p['chat_id'])
    if chat_id in state['blocked']:
        return fail(403, 'Forbidden: bot was blocked by the user')
    if chat_id not in state['started']:
        return fail(400, 'Bad Request: chat not found')
    text = str(p.get('text', ''))
    if p.get('parse_mode') == 'HTML':
        error = check_html(text)
        if error:
            log(f'sendMessage → 400 {error}')
            return fail(400, error)
    msg = {'message_id': next(message_ids), 'from': BOT, 'chat': {'id': chat_id, 'type': 'private'},
           'date': int(time.time()), 'text': text}
    chats.setdefault(chat_id, []).append({'who': 'bot', 'text': text, 'parse_mode': p.get('parse_mode')})
    log(f'бот → {chat_id}: {text!r}')
    return ok(msg)


# ---------- «пользователи» ----------
class UserMessage(BaseModel):
    user_id: int
    text: str
    first_name: str = 'Студент'
    username: str | None = None


def make_update(m: UserMessage) -> dict:
    user = {'id': m.user_id, 'is_bot': False, 'first_name': m.first_name, 'language_code': 'ru'}
    if m.username:
        user['username'] = m.username
    message = {'message_id': next(message_ids), 'from': user,
               'chat': {'id': m.user_id, 'type': 'private', 'first_name': m.first_name},
               'date': int(time.time()), 'text': m.text}
    if m.text.startswith('/'):
        message['entities'] = [{'type': 'bot_command', 'offset': 0, 'length': len(m.text.split()[0])}]
    return {'update_id': next(update_ids), 'message': message}


@app.post('/_simulate/message')
async def simulate_message(m: UserMessage):
    state['started'].add(m.user_id)
    state['blocked'].discard(m.user_id)
    chats.setdefault(m.user_id, []).append({'who': 'user', 'text': m.text})
    update = make_update(m)
    log(f'{m.user_id} → бот: {m.text!r}')
    if not state['webhook_url']:
        state['pending'].append(update)
        new_update.set()
        return {'delivered': 'queued for getUpdates', 'update_id': update['update_id']}

    headers = {'X-Telegram-Bot-Api-Secret-Token': state['secret']} if state['secret'] else {}
    async with httpx.AsyncClient(timeout=10) as client:
        try:
            r = await client.post(state['webhook_url'], json=update, headers=headers)
            status = r.status_code
        except httpx.HTTPError as e:
            status, r = None, None
            state['last_error'] = (int(time.time()), f'Connection error: {type(e).__name__}')
    if status is not None and status >= 300:
        state['last_error'] = (int(time.time()), f'Wrong response from the webhook: {status} {r.reason_phrase}')
        state['pending'].append(update)   # настоящий Telegram будет повторять доставку
    log(f'вебхук ← {status}')
    return {'delivered': 'webhook', 'status': status, 'update_id': update['update_id']}


@app.post('/_simulate/block/{user_id}')
async def simulate_block(user_id: int):
    state['blocked'].add(user_id)
    return {'blocked': user_id}


@app.get('/_chat/{user_id}')
async def chat(user_id: int, after: int = 0):
    return chats.get(user_id, [])[after:]


# ---------- окно чата для проектора ----------
@app.get('/_ui/{user_id}', response_class=HTMLResponse)
async def chat_ui(user_id: int):
    bubbles = []
    for m in chats.get(user_id, []):
        if m['who'] == 'user':
            bubbles.append(f'<div class="m u">{escape(m["text"])}</div>')
        else:  # текст бота уже прошёл проверку HTML в sendMessage
            body = m['text'] if m.get('parse_mode') == 'HTML' else escape(m['text'])
            bubbles.append(f'<div class="m b">{body}</div>')
    return f'''<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="2">
<title>@{BOT["username"]} · имитатор</title>
<style>body{{margin:0;font:15px/1.4 system-ui,sans-serif;background:#d9e4ec}}
header{{background:#517da2;color:#fff;padding:12px 16px;font-weight:600}}
header small{{display:block;font-weight:400;opacity:.8}}
main{{max-width:560px;margin:0 auto;padding:16px;display:flex;flex-direction:column;gap:8px}}
.m{{max-width:80%;padding:8px 12px;border-radius:12px;white-space:pre-wrap;box-shadow:0 1px 1px #0002}}
.u{{align-self:flex-end;background:#effdde}}.b{{align-self:flex-start;background:#fff}}
code{{background:#eef;padding:0 3px;border-radius:3px}}</style>
<header>@{BOT["username"]}<small>имитатор Telegram · чат с пользователем {user_id}</small></header>
<main>{"".join(bubbles)}</main>'''
