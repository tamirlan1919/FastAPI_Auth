"""Бот в режиме polling — для локальной разработки, без публичного адреса.

Запуск (из корня проекта, рядом с uvicorn):
    python -m scripts.run_bot_polling
"""
import asyncio
import logging

from app.bot.setup import BOT_COMMANDS, create_bot, create_dispatcher
from app.core.config import settings
from app.db.database import engine
from app.db.redis_db import create_redis


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
    engine.echo = False  # SQL-лог нужен API, в консоли бота он только мешает

    if settings.telegram_bot_token is None:
        raise SystemExit('Задайте TELEGRAM_BOT_TOKEN в .env')

    redis = create_redis()
    bot = create_bot(settings.telegram_bot_token.get_secret_value(), settings.telegram_api_url)
    dp = create_dispatcher(redis=redis)

    # Пока стоит вебхук, getUpdates отвечает 409 Conflict — снимаем его
    await bot.delete_webhook(drop_pending_updates=True)
    await bot.set_my_commands(BOT_COMMANDS)
    try:
        await dp.start_polling(bot)
    finally:
        await redis.aclose()


if __name__ == '__main__':
    asyncio.run(main())
