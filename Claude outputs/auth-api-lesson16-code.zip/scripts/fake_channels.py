"""Имитация Telethon-клиента для занятия без аккаунта Telegram и для тестов.

Сообщения создаются настоящими объектами Telethon (telethon.tl.types.Message)
и проходят через тот же message_to_post, что и в бою.

    python -m scripts.fake_channels          # auth-api на :8000 с имитацией каналов
    curl -X POST localhost:8000/_fake/channels/fastapi_news/post -d 'Текст #тег'
"""
import itertools
import logging
from datetime import datetime, timedelta, timezone

from telethon.errors import FloodWaitError
from telethon.tl.types import Message, PeerChannel

from app.clients.telegram_channels import ChannelNotFound, PostCallback, message_to_post
from app.schemas.telegram import ChannelPost

logger = logging.getLogger(__name__)
START = datetime(2026, 11, 20, 9, 0, tzinfo=timezone.utc)

CHANNELS: dict[str, list[str | None]] = {
    'fastapi_news': [
        'FastAPI 0.142: что нового\nРазбираем lifespan, новые зависимости и ускорение валидации. #fastapi #python',
        None,  # фото без подписи
        'Pydantic 2.13 быстрее на 15% на больших моделях #pydantic #python',
        'Почему async def с синхронным драйвером БД — плохая идея #fastapi #asyncio',
        'Опрос: на чём вы деплоите FastAPI в 2026? #опрос',
    ],
}
USERS = {'durov'}              # есть такой username, но это человек, а не канал
FLOOD = {'flood_test': 37}     # канал, на котором «Telegram» просит подождать


def make_message(channel_id: int, msg_id: int, text: str | None) -> Message:
    return Message(id=msg_id, peer_id=PeerChannel(channel_id), date=START + timedelta(hours=msg_id),
                   message=text or '', views=100 * msg_id, post=True)


class FakeTelegramChannels:
    def __init__(self, *args, **kwargs) -> None:
        self.callbacks: list[PostCallback] = []
        self.joined: set[str] = set()
        self.ids = itertools.count(100)

    async def start(self) -> None:
        logger.info('Telethon (ИМИТАЦИЯ): вошли как Тестовый аккаунт (id=1)')

    async def stop(self) -> None:
        pass

    def _check(self, username: str) -> str:
        name = username.lstrip('@').lower()
        if name in FLOOD:
            raise FloodWaitError(request=None, capture=FLOOD[name])
        if name in USERS:
            raise ChannelNotFound(f'@{username} — не канал')
        if name not in CHANNELS:
            raise ChannelNotFound(f'@{username} не найден')
        return name

    async def latest_posts(self, username: str, limit: int) -> list[ChannelPost]:
        name = self._check(username)
        texts = CHANNELS[name]
        messages = [make_message(1, i, t) for i, t in enumerate(texts, start=1)]
        messages = list(reversed(messages))[:limit]           # iter_messages: от новых к старым
        return [p for m in messages if (p := message_to_post(m, name)) is not None]

    async def join(self, username: str) -> None:
        self.joined.add(self._check(username))

    def on_new_post(self, callback: PostCallback) -> None:
        self.callbacks.append(callback)

    async def emit(self, username: str, text: str) -> ChannelPost | None:
        name = self._check(username)
        CHANNELS[name].append(text)
        post = message_to_post(make_message(1, len(CHANNELS[name]), text), name)
        if post is not None and name in self.joined:
            for callback in self.callbacks:
                await callback(post)
        return post


def build_app():
    import app.main as main
    from fastapi import Body, HTTPException
    from pydantic import SecretStr

    main.TelegramChannels = FakeTelegramChannels
    main.settings.telethon_api_id = 1
    main.settings.telethon_api_hash = SecretStr('fake')
    main.settings.telethon_session = SecretStr('fake')

    @main.app.post('/_fake/channels/{channel}/post', include_in_schema=False)
    async def fake_post(channel: str, text: str = Body(..., media_type='text/plain')):
        tg = main.app.state.tg_channels
        if channel.lower() not in tg.joined:
            raise HTTPException(409, 'аккаунт не подписан на канал — новые посты не придут')
        post = await tg.emit(channel, text)
        return {'emitted': post.url if post else None}

    return main.app


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(build_app(), port=8000)
