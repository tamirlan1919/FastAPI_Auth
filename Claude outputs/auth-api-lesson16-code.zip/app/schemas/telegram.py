from datetime import datetime

from pydantic import BaseModel

from app.schemas.post import PostOut


class TelegramLinkOut(BaseModel):
    url: str
    expires_in: int


class ChannelPost(BaseModel):
    """Пост из Telegram-канала — только то, что нам нужно, без объектов Telethon."""
    channel: str
    message_id: int
    date: datetime
    text: str
    views: int | None = None

    @property
    def url(self) -> str:
        return f'https://t.me/{self.channel}/{self.message_id}'


class ImportResult(BaseModel):
    channel: str
    fetched: int
    imported: int
    skipped: int
    posts: list[PostOut]


class WatchOut(BaseModel):
    channel: str
    watching: bool
