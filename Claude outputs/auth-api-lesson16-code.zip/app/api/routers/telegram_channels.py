from fastapi import APIRouter, HTTPException, Query, status
from telethon.errors import FloodWaitError, RPCError

from app.api.deps import CurrentUserDep, PostRepoDep, RedisDep, TelegramChannelsDep
from app.clients.telegram_channels import ChannelNotFound
from app.schemas.post import PostOut
from app.schemas.telegram import ImportResult, WatchOut
from app.services.channel_import import import_posts, watchers_key

router = APIRouter(prefix='/telegram/channels', tags=['Telegram-каналы'])


def telegram_error(e: Exception) -> HTTPException:
    if isinstance(e, ChannelNotFound):
        return HTTPException(status.HTTP_404_NOT_FOUND, str(e))
    if isinstance(e, FloodWaitError):
        return HTTPException(status.HTTP_429_TOO_MANY_REQUESTS,
                             f'Telegram просит подождать {e.seconds} с',
                             headers={'Retry-After': str(e.seconds)})
    return HTTPException(status.HTTP_502_BAD_GATEWAY, f'Ошибка Telegram: {e}')


@router.post('/{channel}/import', response_model=ImportResult)
async def import_channel(
    channel: str,
    current_user: CurrentUserDep,
    post_repo: PostRepoDep,
    redis: RedisDep,
    tg: TelegramChannelsDep,
    limit: int = Query(20, ge=1, le=100),
):
    """Последние посты публичного канала → посты текущего пользователя (без повторов)."""
    try:
        items = await tg.latest_posts(channel, limit)
    except (ChannelNotFound, RPCError) as e:
        raise telegram_error(e)
    created = await import_posts(post_repo, redis, current_user.id, items)
    return ImportResult(
        channel=channel,
        fetched=len(items),
        imported=len(created),
        skipped=len(items) - len(created),
        posts=[PostOut.model_validate(p) for p in created],
    )


@router.post('/{channel}/watch', response_model=WatchOut)
async def watch_channel(channel: str, current_user: CurrentUserDep, redis: RedisDep, tg: TelegramChannelsDep):
    """Новые посты канала будут приходить в auth-api сами, а владельцу — уведомление в бота."""
    try:
        await tg.join(channel)
    except (ChannelNotFound, RPCError) as e:
        raise telegram_error(e)
    await redis.sadd(watchers_key(channel), current_user.id)
    return WatchOut(channel=channel, watching=True)


@router.delete('/{channel}/watch', response_model=WatchOut)
async def unwatch_channel(channel: str, current_user: CurrentUserDep, redis: RedisDep):
    await redis.srem(watchers_key(channel), current_user.id)
    return WatchOut(channel=channel, watching=False)
