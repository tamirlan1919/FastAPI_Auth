"""Посты из Telegram-каналов → посты auth-api (+ уведомление через бота)."""
import logging
import re

from aiogram import Bot, html
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from redis.asyncio import Redis

from app.db.database import async_session_maker
from app.db.models import Post
from app.repositories.post_repo import PostRepo
from app.repositories.user_repo import UserRepo
from app.schemas.telegram import ChannelPost

logger = logging.getLogger(__name__)

TITLE_MAX = 200
TAGS_MAX = 10
HASHTAG_RE = re.compile(r'#(\w{2,50})')


def imported_key(user_id: int) -> str:
    return f'tg:imported:{user_id}'


def watchers_key(channel: str) -> str:
    return f'tg:watchers:{channel.lower()}'


def post_title(text: str) -> str:
    """Первая строка без хештегов (они уйдут в теги), не длиннее 200 символов."""
    clean = HASHTAG_RE.sub('', text)
    lines = [' '.join(line.split()) for line in clean.splitlines()]
    title = next((line for line in lines if len(line) >= 3), ' '.join(clean.split()) or 'Пост из Telegram')
    return title if len(title) <= TITLE_MAX else title[:TITLE_MAX - 1] + '…'


def post_tags(text: str) -> list[str]:
    tags = [tag.lower() for tag in HASHTAG_RE.findall(text)]
    return list(dict.fromkeys(tags))[:TAGS_MAX]


async def import_posts(post_repo: PostRepo, redis: Redis, user_id: int, posts: list[ChannelPost]) -> list[Post]:
    """Создаёт посты, которых этот пользователь ещё не импортировал. Старые — первыми."""
    created = []
    for item in sorted(posts, key=lambda p: (p.channel, p.message_id)):
        marker = f'{item.channel.lower()}:{item.message_id}'
        # SADD вернёт 0, если такой элемент уже был → пост уже импортирован
        if not await redis.sadd(imported_key(user_id), marker):
            continue
        try:
            post = await post_repo.create(post_title(item.text), user_id, post_tags(item.text))
        except Exception:
            await redis.srem(imported_key(user_id), marker)  # не создали — снимаем отметку
            raise
        created.append(post)
    return created


async def handle_new_post(item: ChannelPost, redis: Redis, bot: Bot | None) -> None:
    """Новый пост в канале: импортировать каждому подписчику и написать ему в бота."""
    watchers = await redis.smembers(watchers_key(item.channel))
    if not watchers:
        return
    async with async_session_maker() as session:
        post_repo, user_repo = PostRepo(session), UserRepo(session)
        for user_id in sorted(int(w) for w in watchers):
            created = await import_posts(post_repo, redis, user_id, [item])
            if not created:
                continue
            logger.info('Пост %s импортирован для user_id=%s', item.url, user_id)
            user = await user_repo.get_by_id(user_id)
            if bot is None or user is None or user.telegram_id is None:
                continue
            try:
                await bot.send_message(
                    user.telegram_id,
                    f'📢 Новый пост в @{html.quote(item.channel)}\n'
                    f'{html.bold(html.quote(created[0].title))}\n{item.url}',
                )
            except TelegramForbiddenError:
                # пользователь заблокировал бота — писать ему больше нельзя
                await user_repo.set_telegram_id(user, None)
                logger.info('user_id=%s заблокировал бота — Telegram отвязан', user_id)
            except TelegramBadRequest as e:
                logger.warning('Не отправили уведомление user_id=%s: %s', user_id, e)
