"""Чтение Telegram-каналов от имени пользовательского аккаунта (Telethon, MTProto)."""
import logging
from typing import Awaitable, Callable

from telethon import TelegramClient, events
from telethon.errors import UsernameInvalidError, UsernameNotOccupiedError
from telethon.sessions import StringSession
from telethon.tl.custom import Message
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.types import Channel

from app.schemas.telegram import ChannelPost

logger = logging.getLogger(__name__)

PostCallback = Callable[[ChannelPost], Awaitable[None]]


class ChannelNotFound(Exception):
    pass


def message_to_post(message: Message, channel: str) -> ChannelPost | None:
    """Сообщение Telethon → наша модель. Фото без подписи и служебные сообщения пропускаем."""
    text = (message.raw_text or '').strip()
    if not text:
        return None
    return ChannelPost(
        channel=channel,
        message_id=message.id,
        date=message.date,
        text=text,
        views=message.views,
    )


class TelegramChannels:
    def __init__(self, api_id: int, api_hash: str, session: str) -> None:
        # StringSession: вся авторизация — одна строка из .env, без файла *.session на диске
        self.client = TelegramClient(StringSession(session), api_id, api_hash)

    async def start(self) -> None:
        await self.client.connect()
        if not await self.client.is_user_authorized():
            await self.client.disconnect()
            raise RuntimeError('Telethon: сессия не авторизована — запустите python -m scripts.telethon_login')
        me = await self.client.get_me()
        logger.info('Telethon: вошли как %s (id=%s)', me.first_name, me.id)

    async def stop(self) -> None:
        await self.client.disconnect()

    async def _channel(self, username: str) -> Channel:
        try:
            entity = await self.client.get_entity(username)
        except (ValueError, UsernameInvalidError, UsernameNotOccupiedError) as e:
            raise ChannelNotFound(f'@{username} не найден') from e
        if not isinstance(entity, Channel) or entity.megagroup:
            raise ChannelNotFound(f'@{username} — не канал')
        return entity

    async def latest_posts(self, username: str, limit: int) -> list[ChannelPost]:
        entity = await self._channel(username)
        posts = []
        async for message in self.client.iter_messages(entity, limit=limit):
            post = message_to_post(message, entity.username or username)
            if post is not None:
                posts.append(post)
        return posts

    async def join(self, username: str) -> None:
        """Подписаться: новые посты приходят только из каналов, где аккаунт состоит."""
        entity = await self._channel(username)
        await self.client(JoinChannelRequest(entity))

    def on_new_post(self, callback: PostCallback) -> None:
        # message.post=True только у постов каналов — не у групп и не у личных сообщений
        @self.client.on(events.NewMessage(func=lambda e: bool(e.message.post)))
        async def handler(event: events.NewMessage.Event) -> None:
            chat = await event.get_chat()
            if not getattr(chat, 'username', None):
                return  # приватный канал без username — ссылку не построить
            post = message_to_post(event.message, chat.username)
            if post is None:
                return
            try:
                await callback(post)
            except Exception:
                logger.exception('Не удалось обработать пост %s', post.url)
