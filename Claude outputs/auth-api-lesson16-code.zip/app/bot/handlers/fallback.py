from aiogram import Router
from aiogram.types import Message

router = Router(name='fallback')


@router.message()
async def unknown(message: Message) -> None:
    # Сюда попадает всё, что не забрали роутеры выше
    await message.answer('Не понял 🤔 Команды: /me /posts /unlink')
