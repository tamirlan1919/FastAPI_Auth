import logging

from aiogram.types import ErrorEvent

logger = logging.getLogger(__name__)


# Регистрируем на САМОМ Dispatcher (см. setup.py): ошибки всплывают от роутера к родителю,
# а соседний роутер их не увидит
async def on_error(event: ErrorEvent) -> bool:
    logger.exception(
        'Ошибка при обработке update_id=%s: %s',
        event.update.update_id, event.exception,
        exc_info=event.exception,
    )
    message = event.update.message
    if message is not None:
        await message.answer('Что-то пошло не так. Мы уже разбираемся 🙏')
    return True  # ошибка обработана → вебхук ответит 200, Telegram не будет повторять апдейт
