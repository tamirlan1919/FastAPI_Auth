from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.enums import ParseMode
from aiogram.types import BotCommand
from redis.asyncio import Redis

from app.bot.handlers import account, errors, fallback, start


def create_bot(token: str, api_url: str = 'https://api.telegram.org') -> Bot:
    session = AiohttpSession(api=TelegramAPIServer.from_base(api_url))
    return Bot(
        token=token,
        session=session,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


def create_dispatcher(redis: Redis) -> Dispatcher:
    # Всё, что передали в Dispatcher(...), приходит в хендлеры аргументом с тем же именем
    dp = Dispatcher(redis=redis)

    # Порядок важен: первый подходящий хендлер забирает апдейт
    dp.include_routers(
        start.router,
        account.router,
        fallback.router,  # всё, что не забрали выше
    )
    dp.errors.register(errors.on_error)
    return dp


BOT_COMMANDS = [
    BotCommand(command='me', description='Мой профиль в auth-api'),
    BotCommand(command='posts', description='Мои посты'),
    BotCommand(command='unlink', description='Отвязать Telegram'),
]
